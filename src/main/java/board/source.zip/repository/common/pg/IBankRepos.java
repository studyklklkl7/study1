package com.tenminds.repository.common.pg;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.tenminds.common.util.PagingUtil;
import com.tenminds.domain.cmn.auth.model.AuthCnd;
import com.tenminds.domain.cmn.auth.model.AuthDto;

public interface IBankRepos{
	

}