package com.tenminds.service.contract;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.tenminds.common.configuration.database.DataSource;
import com.tenminds.common.configuration.database.DatabaseContextHolder;
import com.tenminds.common.configuration.database.DatabaseType;
import com.tenminds.common.configuration.database.Tx;
import com.tenminds.common.consts.LogMdc;
import com.tenminds.common.consts.PayInfo;
import com.tenminds.common.consts.Security;
import com.tenminds.common.util.AES256Util;
import com.tenminds.common.util.DateUtil;
import com.tenminds.common.util.PagingUtil;
import com.tenminds.common.util.StringUtil;
import com.tenminds.domain.common.security.LoginInfo;
import com.tenminds.domain.contract.entity.ContCertNoM;
import com.tenminds.domain.contract.entity.ContM;
import com.tenminds.domain.contract.entity.ContRegGrp;
import com.tenminds.domain.contract.model.ContractDto;
import com.tenminds.domain.contract.model.repsonse.ContCurPayInfoDto;
import com.tenminds.domain.contract.model.repsonse.ContCustAgreeDto;
import com.tenminds.domain.contract.model.repsonse.ContPayRoundInfoDto;
import com.tenminds.domain.contract.model.request.AccountCertRequestDto;
import com.tenminds.domain.contract.model.request.ContCertNoMRequestDto;
import com.tenminds.domain.contract.model.request.ContCustInfoRequestDto;
import com.tenminds.domain.contract.model.request.ContMRequestDto;
import com.tenminds.domain.contract.model.request.ContPayInfoRequestDto;
import com.tenminds.domain.contract.model.request.ContRegGrpRequestDto;
import com.tenminds.domain.contract.model.request.CustAgreeRequestDto;
import com.tenminds.domain.contract.model.request.SrchContractRequestDto;
import com.tenminds.domain.product.model.ProductDto;
import com.tenminds.mapper.contract.AccountCertMapper;
import com.tenminds.mapper.contract.ContractMapper;
import com.tenminds.repository.contract.ContRepos;
import com.tenminds.repository.contractRegGrp.ContRegGrpRepos;
import com.tenminds.service.common.pg.BankService;
import com.tenminds.service.ksnet.KsnetService;
import com.tenminds.service.product.ProductService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * com.tenminds.service.contract
 * ContService.java

 * Description : 계약 등록, 수정, 계좌인증 등 계약관리 서비스 입니다.<br>
 * Date : 2022. 9. 30.<br>
 * History :<br>
 * - 작성자 : Lee, 날짜 : 2022. 9. 30., 설명 : 최초작성<br>
 *
 * @author Lee
 * @version 1.0
 */
@Slf4j(topic = "DY_LOGGER")
@RequiredArgsConstructor
@Service
public class ContService {
	private final ContractMapper contractMapper;

	@Autowired
	private ContRegGrpRepos contRegGrpRepos;

	@Autowired
	private ContRepos contrepos;

	private final AccountCertMapper accountCertMapper;

	private final KsnetService ksnetService;

	private final BankService bankService;

	private final ProductService productService;

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public PagingUtil selectContList(SrchContractRequestDto srchContM) throws Exception {
		LogMdc.name.accept("contract");
			srchContM.of();
			List<ContractDto> list = contractMapper.selectContList(srchContM);

			for(int i=0; i < list.size(); i++) {
				list.get(i).setCustNm( StringUtil.maskingUserName( list.get(i).getCustNm() ) );
				list.get(i).setMpNo( StringUtil.phoneMasking(list.get(i).getMpNo()));
				list.get(i).setBirthDate( StringUtil.birthMasking( list.get(i).getBirthDate() ) );
			}


			int cnt = contractMapper.selectContCount(srchContM);

		return new PagingUtil(list,srchContM,cnt,"contListFn.search", true);
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public ContractDto contractUpdateInfoBySrchContM(SrchContractRequestDto srchContM) throws Exception {
		LogMdc.name.accept("contract");
		ContractDto contractDto = null;
		try {
			contractDto = contractMapper.selectContractDetail(srchContM);
		} catch (Exception e) {
			log.error("CONTRACT INFO ERROR [CONTRACT_NO] : " + srchContM.getSrchContractNo() + " / [MESSAGE] : " + e.toString());
		}
		return contractDto;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public int countContractByPdtCd(String srchPdtCd) {
		LogMdc.name.accept("contract");
		int result = -1;
		try {
			result = contractMapper.countContractByPdtCd(srchPdtCd);
		} catch (Exception e) {
			log.error("CONTRACT COUNT BY PDTCD ERROR [PDT_CD] : " + srchPdtCd + " / [MESSAGE] " + e.toString());
		}
		return result;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public ContractDto selectContractDetail(SrchContractRequestDto srchContM) {
		LogMdc.name.accept("contract");
		ContractDto result = null;
		try {
			result = contractMapper.selectContractDetail(srchContM);
		} catch (Exception e) {
			log.error("CONTRACT GET INFO ERROR [CONTRACT_NO] : " + srchContM.getSrchContractNo() + " / [MESSAGE] " + e.toString());
		}
		return result;
	}


	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public List<ContCustAgreeDto> selectContCustAgreeList(int custNo) {
		LogMdc.name.accept("contract");
		List<ContCustAgreeDto> list = null;
		try {
			list = contractMapper.selectContCustAgreeList(custNo);
		} catch (Exception e) {
			log.error("CONTRACT CUST AGREE ERROR [CUST_NO] : " + custNo + " / [MESSAGE] " + e.toString());
		}
		return list;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public List<ContPayRoundInfoDto> selectContPayRoundInfo(SrchContractRequestDto srchContM){
		LogMdc.name.accept("contract");
		List<ContPayRoundInfoDto> list = null;
		try {
			list = contractMapper.selectContPayRoundInfo(srchContM);
		} catch (Exception e) {
			log.error("CONTRACT PAY ROUND INFO ERROR [CONTRACT_NO] : " + srchContM.getSrchContractNo() + " / [MESSAGE] " + e.toString());
		}
		return list;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public ContCurPayInfoDto getContCurPayInfo(SrchContractRequestDto srchContM) {
		ContCurPayInfoDto contCurPayInfoDto = null;
		LogMdc.name.accept("contract");
		try {
			contCurPayInfoDto = contractMapper.getContCurPayInfo(srchContM);
		} catch (Exception e) {
			log.error("CONTRACT CUR PAY INFO ERROR [CONTRACT_NO] : " + srchContM.getSrchContractNo() + " / [MESSAGE] " + e.toString());
		}
		return contCurPayInfoDto;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public int selectContCount(SrchContractRequestDto srchContract) {
		LogMdc.name.accept("contract");
		int result = -1;
		try {
			result = contractMapper.selectContCount(srchContract);
		} catch (Exception e) {
			log.error("CONTRACT COUNT ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public List<ContractDto> selectContListNotPage(SrchContractRequestDto srchContract) {
		LogMdc.name.accept("contract");
		List<ContractDto> list = null;
		try {
			list = contractMapper.selectContList(srchContract);
		} catch (Exception e) {
			log.error("CONTRACT LIST ERROR [MESSAGE] " + e.toString());
		}
		return list;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public List<ContractDto> selectPetListByCont(SrchContractRequestDto srchContract) {
		LogMdc.name.accept("contract");
		List<ContractDto> list = null;
		try {
			list = contractMapper.selectContList(srchContract);
		} catch (Exception e) {
			log.error("PET LIST BY CONT ERROR [MESSAGE] " + e.toString());
		}
		return list;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public List<ContractDto> selectCertNoListByPayInfo(SrchContractRequestDto srchContM) {
		LogMdc.name.accept("contract");
		List<ContractDto> list = null;
		try {
			list = contractMapper.selectCertNoListByPayInfo(srchContM);
		} catch (Exception e) {
			log.error("PET LIST BY CONT ERROR [MESSAGE] " + e.toString());
		}
		return list;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public int checkAccountState(int payInfoNo) {
		LogMdc.name.accept("contract");
		int result = -1;
		try {
			result = contractMapper.checkAccountState(payInfoNo);
		} catch (Exception e) {
			log.error("CHECK ACCOUNT STATE ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}


	@Transactional(Tx.MY_BATIS)
	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public int updateContract(ContractDto contractDto) {
		LogMdc.name.accept("contract");
		int result = -1;
		try {
			//계약자 정보 업데이트
			result = contractMapper.updateContractCust(contractDto);
			if(result != 1) {
				log.error("UPDATE CONTRACT CUST ERROR");
				throw new Exception();
			}

			//선택적 수집,이용 (전화)
			contractDto.setAgreeTypeCd(5);
			contractDto.setAgree(contractDto.getAgreeTypeCd5());
			result = contractMapper.updateCustAgree(contractDto);
			if(result != 1) {
				log.error("UPDATE CONTRACT CUST AGREE ERROR [AGREE_TYPE_CD] : "+contractDto.getAgreeTypeCd());
				throw new Exception();
			}

			//선택적 수집,이용 (문자)
			contractDto.setAgreeTypeCd(6);
			contractDto.setAgree(contractDto.getAgreeTypeCd6());
			result = contractMapper.updateCustAgree(contractDto);
			if(result != 1) {
				log.error("UPDATE CONTRACT CUST AGREE ERROR [AGREE_TYPE_CD] : "+contractDto.getAgreeTypeCd());
				throw new Exception();
			}

			//선택적 수집,이용 (이메일)
			contractDto.setAgreeTypeCd(7);
			contractDto.setAgree(contractDto.getAgreeTypeCd7());
			result = contractMapper.updateCustAgree(contractDto);
			if(result != 1) {
				log.error("UPDATE CONTRACT CUST AGREE ERROR [AGREE_TYPE_CD] : "+contractDto.getAgreeTypeCd());
				throw new Exception();
			}

			//선택적 수집,이용 (서면)
			contractDto.setAgreeTypeCd(8);
			contractDto.setAgree(contractDto.getAgreeTypeCd8());
			result = contractMapper.updateCustAgree(contractDto);
			if(result != 1) {
				log.error("UPDATE CONTRACT CUST AGREE ERROR [AGREE_TYPE_CD] : "+contractDto.getAgreeTypeCd());
				throw new Exception();
			}

			//선택적 제공
			contractDto.setAgreeTypeCd(9);
			contractDto.setAgree(contractDto.getAgreeTypeCd9());
			result = contractMapper.updateCustAgree(contractDto);
			if(result != 1) {
				log.error("UPDATE CONTRACT CUST AGREE ERROR [AGREE_TYPE_CD] : "+contractDto.getAgreeTypeCd());
				throw new Exception();
			}

			if(contractDto.getContractStateCd() != -1) {

				//현재 계약상태
				int prevContractStateCd = contractMapper.getContractStateCd(contractDto.getContractNo());

				//현재 계약상태가 정상, 연체, 완납, 실효 일 때만 변경가능
				//변경 계약상태는 직권해지, 해약, 철회, 케어완료로만 변경가능
				if((prevContractStateCd == 2 || prevContractStateCd == 3 || prevContractStateCd == 4 || prevContractStateCd == 5)
						&& (contractDto.getContractStateCd() ==7 || contractDto.getContractStateCd() ==8 || contractDto.getContractStateCd() ==9 || contractDto.getContractStateCd() ==10)) {
					//계약 변경 히스토리 저장
					result = contractMapper.insertContStateH(contractDto);
					if(result != 1) {
						log.error("INSERT CONTRACT STATE HISTORY ERROR");
						throw new Exception();
					}
				}
			}

			//계약 업데이트 (채널경로, 모집자)
			result = contractMapper.updateContract(contractDto);
			if(result != 1) {
				log.error("UPDATE CONTRACT ERROR");
				throw new Exception();
			}

			//계좌인증 체크  && 초회납 체크
			if(contractMapper.checkAccountState(contractDto.getPayInfoNo()) == 2 && contractMapper.checkCurPayTimes(contractDto.getContractNo()) > 0 ) {
				//납입정보 업데이트 (이체일자)
				result = contractMapper.updateContPayInfo(contractDto);
				if(result != 1) {
					log.error("UPDATE CONTRACT PAY INFO ERROR");
					throw new Exception();
				}

				//예금주 관계가 본인이 아닐 경우에만 업데이트  => 1. 본인
				if(contractMapper.checkDepRelTypeCd(contractDto.getPmNo()) != 1) {
					//결제수단_은행계좌정보 업데이트 (예금주관계, 예금주 연락처)
					result = contractMapper.updateContractContPmBaInfo(contractDto);
					if(result != 1) {
						log.error("UPDATE CONTRACT PM BA INFO ERROR");
						throw new Exception();
					}
				}

			}

		} catch (Exception e) {
			log.error("UPDATE CONTRACT ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public int checkCurPayTimes(String contractNo) {
		LogMdc.name.accept("contract");
		int result = -1;
		try {
			result = contractMapper.checkCurPayTimes(contractNo);
		} catch (Exception e) {
			log.error("CHECK CUR PAY TIMES ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}

	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public List<ContractDto> selectArsAgreeRequest(String contractNo) {
		LogMdc.name.accept("contract");
		List<ContractDto> list = null;
		try {
			list = contractMapper.selectArsAgreeRequest(contractNo);
		} catch (Exception e) {
			log.error("ARS AGREE REQUEST LIST ERROR [MESSAGE] " + e.toString());
		}
		return list;
	}


	/************************************************************************/



	@Transactional(Tx.JPA)
	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public Integer contCreateProcAjax2(@ModelAttribute("contRegGrpRequest") ContRegGrpRequestDto contRegGrpRequest, @ModelAttribute("contMRequest") ContMRequestDto contMRequest, @AuthenticationPrincipal LoginInfo loginInfo) {
		LogMdc.name.accept("ContM");
		Integer result = 0;
		try {
			int accCnt = 2;
			/*
			 * String regMgrId = loginInfo.getManagerId(); //등록자 ID
			 * contRegGrpRequest.setRegMgrId(regMgrId); //set
			 * contRegGrpRequest.setInsuAccCnt(accCnt);
			 */
			ContRegGrp contRegGrp = contRegGrpRequest.regToEntity();

ContCertNoMRequestDto contCertNoMRequest = new ContCertNoMRequestDto(); //임시

contCertNoMRequest.setRegMgrId(loginInfo.getManagerId());

			ContM contM = null;
			ContCertNoM contCertNoM = null;
			while(accCnt--> 0) {
				/*
				 * contMRequest.setContRegGrp(contRegGrp); contMRequest.setAgentOrdNo("1111");
				 * contMRequest.setMonthPayAmount(1000);
				 */

				contMRequest.setContRegGrp(contRegGrp);

contCertNoM = contCertNoMRequest.regToEntity();

contMRequest.setContCertNoM(contCertNoM);

				contM = contMRequest.regToEntity(); //contM Entity



//log.info("contM => " + contM.toString());

				//contCertNoMRequest.setContM(contM);
				//contCertNoM = contCertNoMRequest.regToEntity(); //contCertNoM Entity

//log.info("contCertNoM => " + contCertNoM.toString());
				//contM.putContCertNoM(contCertNoM);
				contrepos.save(contM);


				contRegGrp.putContM(contM);
			}
log.info("저장 start === ");
			//ContRegGrp contregGrp =
			result = contRegGrpRepos.save(contRegGrp).getCrGrpNo();
log.info("contRegGrp =>" +contRegGrp.toString());
			//contrepos.save(contM);
log.info("contM =>" +contM.toString());

log.info("저장 end === ");
		} catch (Exception e) {
			// TODO: handle exception
			log.error("contCreateProcAjax2 =>" + e.toString());
		}

		return result;
	}





	/**
	 * 계좌인증 처리
	 * @param AccountCertRequestDto accountCertRequestDto
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	@Transactional(Tx.MY_BATIS)
	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)
	public Map<String, Object> contMethodPmBaAuthInsertProc(AccountCertRequestDto accountCertRequestDto) throws Exception {
		LogMdc.name.accept("contract-accountCert");
		Map<String, Object> returnMap = null;
		Map<String, Object> saveMap = null;
		HashMap<String, Object> ksnetRetrnMap = null;
		//int accCertResultCnt = 0; //계좌 인증 DB 등록 결과값
		String rtnReqNo = "";//계좌 인증 DB 등록 결과값
		String isPmNo = ""; //기존 결제 수단고유번호

		try{
			returnMap = new HashMap<String, Object>();
			saveMap = new HashMap<String, Object>();
			String payTypeCd = PayInfo.PAY_TYPE_CMS_CD; //납입방법코드(1: CMS(은행자동이체), 2: 카드)
			String dipositor = accountCertRequestDto.getPopDepositor(); //예금주명
			int depRelTypeCd = accountCertRequestDto.getPopDepRelTypeCd(); //예금주 관계 코드

			//은행코드 가져오기 ('pg사/우리펫')
			String[] arrBank = null;
			arrBank = accountCertRequestDto.getPopBankCd().split("/");
			String bankCd = arrBank[0]; //은행코드
			int isUse = 1; //은행코드 관리 사용여부(1:사용, 2:미사용)
			int wmBankCd = Integer.parseInt(arrBank[1]); //우리마인즈 은행코드
			String accountNo = accountCertRequestDto.getPopAccountNo(); //계좌번호
			String encAccountNo = ""; //암호화 계좌번호
			String reqNo = ""; //전문 요청 키
			int pgCd = 1;	//PG사 구분코드(1:KSNET)
			String managerId = ""; //관리자ID 외부 링크시(팝업) 로그인 정보 없음
			String pmNo = ""; //결제수단고유번호
			int isAuth = 1; //인증여부(1:미인증, 2:인증완료)->authResultCd값이 성공 이면 인증완료, 요청, 실패 이면 미인증
			int authResultCd = 1; //인증결과코드(0:실패, 1:요청, 2:성공)
			String aahNo = "";//계좌인증고유번호
			int srchIsAuth = 0;	//은행계좌 정보 인증여부(1:미인증, 2:인증완료)
			String ksnetResult = ""; //인증 결과값
			String ksnetResultNm = ""; //인증 결과 예금주명
			String result = ""; //결과코드
			int dupCnt = 0;
			int dbResult1 = 0;
			int dbResult2 = 0;
			int dbResult3 = 0;


			//생성자
			ContractDto contractDto = null;
			//1.인증 완료 된 동일 예금주, 은행코드, 계좌번호가 존재 할 시 인증 하지 않고, 기존 결제수단 고유 번호로 대체
			srchIsAuth = 2;
			accountCertRequestDto.setIsAuth(srchIsAuth);

			//은행코드(PG사 은행코드->우리마인즈 은행코드로 변환)
			//BankResponseDto bnkReponseDto = bankService.bankInfoByPgCdPgBankCd(pgCd, bankCd);
			//wmBankCd = bnkReponseDto.getWipetBankCd(); //우리 마인즈 은행코드

			//데이타소스 변경(서비스내에서 다른 서비스 호출시 기존 데이터 소스를 계속 유지 할 시 정의)
			//DatabaseContextHolder.set(DatabaseType.DB_MARIA_WIPET_SVC);
			encAccountNo = AES256Util.strEncode(accountNo, Security.AES_SECRET_KEY);
			accountCertRequestDto.setPopAccountNo(encAccountNo);
			accountCertRequestDto.setPopBankCd(Integer.toString(wmBankCd));
			dupCnt = accountCertMapper.selectContAccountCertCnt(accountCertRequestDto);

			if(dupCnt > 0){ //이미 인증 받은 내역이 있음
				//기존 결제수단고유번호 조회
				isPmNo = accountCertMapper.selectContAccountCert(accountCertRequestDto);
				returnMap.put("result", "2");
				returnMap.put("pmNo", isPmNo);

			}else{//인증 받은 내역이 없을 경우
				//생성자
				contractDto = new ContractDto();

				//미인증 된 내역 있는 지 확인
				srchIsAuth = 1; //은행계좌 정보 인증여부(1:미인증, 2:인증완료)
				accountCertRequestDto.setIsAuth(srchIsAuth);

				dupCnt = accountCertMapper.selectContAccountCertCnt(accountCertRequestDto);


				if(dupCnt > 0){ //이미 이전에 (미)인증 시도 한 내역이 있으면
					//기존 결제수단고유번호 조회
					isPmNo = accountCertMapper.selectContAccountCert(accountCertRequestDto);

					//1.계약-계좌인증히스토리 등록
					//시퀀스 조회
					aahNo = contractMapper.selectSeqContBaAuthH(); //계좌인증고유번호
					//set
					contractDto.setAahNo(aahNo);
					contractDto.setPgCd(pgCd);
					contractDto.setAuthResultCd(authResultCd);
					contractDto.setPmNo(isPmNo);
					//등록
					dbResult1 = contractMapper.insertContBaAuthH(contractDto);

					if(dbResult1 > 0) {
						//2.인증 시도
						//set
						saveMap.put("selBank", bankCd);
						saveMap.put("reqNo", aahNo);
						saveMap.put("accountNum", accountNo);
						rtnReqNo = ksnetService.accountCertInsert(saveMap);

						if(!rtnReqNo.equals("")) { //인증 요청 등록 성공이면
							ksnetRetrnMap = new HashMap<String, Object>();
							//3.인증 결과 수신
							ksnetRetrnMap = ksnetService.accountCertInfo(saveMap);
							ksnetResult = ksnetRetrnMap.get("result").toString();	//인증 결과값
							ksnetResultNm = ksnetRetrnMap.get("recv_name").toString(); //인증 결과 예금주명
							if(ksnetResult.equals("1")) { //인증 수신 결과 성공
								contractDto.setDepositorUpYn("Y");
								if(dipositor.equals(ksnetResultNm)) { //입력, 인증 결과 예금주명 같다면
									authResultCd = 2; //성공
									isAuth = 2; //인증완료
									result = "1";//완료
									returnMap.put("pmNo", isPmNo); //기존 결제 수단고유번호
									contractDto.setDepositor(dipositor);
								}else {
									authResultCd = 0; //실패
									isAuth = 1; //미인증
									result = "-88"; //예금주 명이 다름
									returnMap.put("pmNo", "");
									//예금주명이 다르기 때문에 ""로 변경
									contractDto.setDepositor("");
								}

								//6.계약-계좌인증히스토리 처리결과 코드 수정
								contractDto.setAuthResultCd(authResultCd);
								contractDto.setAahNo(aahNo);
								contractMapper.updateContBaAuthH(contractDto);

								//7.계약-결제수단_은행계좌정보 수정
								contractDto.setIsAuth(isAuth);
								contractDto.setAahNo(aahNo);
								contractDto.setPmNo(isPmNo); //기존 결제 수단고유번호
								contractMapper.updateContPmBaInfo(contractDto);

								returnMap.put("result", result);


							}else{ //인증 수신 결과 실패
								log.error("ContService > accountCertInfo recv_err_code : " + ksnetResult);
								authResultCd = 0; //실패
								isAuth = 1; //미인증
								//6.계약-계좌인증히스토리 처리결과 코드 수정
								contractDto.setAuthResultCd(authResultCd);
								contractDto.setAahNo(aahNo);
								contractMapper.updateContBaAuthH(contractDto);

								//7.계약-결제수단_은행계좌정보 수정
								contractDto.setIsAuth(isAuth);
								contractDto.setAahNo(aahNo);
								contractDto.setPmNo(isPmNo); //기존 결제 수단고유번호
								contractMapper.updateContPmBaInfo(contractDto);
								returnMap.put("result", "-99");
								returnMap.put("pmNo", "");
							}



						}else { //인증 요청 등록 실패
							//3.계약-계좌인증히스토리 처리결과 코드 수정
							authResultCd = 0; //실패
							contractDto.setAuthResultCd(authResultCd);
							contractDto.setAahNo(aahNo);
							contractMapper.updateContBaAuthH(contractDto);


							//4.계약-결제수단_은행계좌정보 수정
							isAuth = 1; //미인증
							contractDto.setIsAuth(isAuth);
							contractDto.setAahNo(aahNo);
							contractDto.setPmNo(isPmNo);
							contractMapper.updateContPmBaInfo(contractDto);
							returnMap.put("result", "-99");
							returnMap.put("pmNo", "");
							log.error("ContService > accountCertInsert error : " + rtnReqNo);
						}
					}



				}else { //인증 최도 시도

					//1.계약-결제수단 정보 등록
					//시퀀스 조회
					pmNo = contractMapper.selectSeqContPayMethodInfo(); //결제수단고유번호

					//set
					contractDto.setPmNo(pmNo);
					contractDto.setMethodPayTypeCd(payTypeCd);
					//등록
					dbResult1 = contractMapper.insertContPayMethodInfo(contractDto);

					if(dbResult1 > 0){
						//2.계약-결제수단_은행계좌정보 등록
						//set
						contractDto.setPmNo(pmNo);
						contractDto.setIsAuth(isAuth);
						//은행코드(PG사 은행코드->우리마인즈 은행코드로 변환)
						//BankResponseDto bnkReponseDto = bankService.bankInfoByPgCdPgBankCd(pgCd, bankCd);
						//wmBankCd = bnkReponseDto.getWipetBankCd(); //우리 마인즈 은행코드
						contractDto.setBankCd(wmBankCd);
						//contractDto.setAccountNo(accountNo);
						contractDto.setAccountNo(encAccountNo); //AES암호화
						contractDto.setDepositor(dipositor);
						contractDto.setDepRelTypeCd(depRelTypeCd);
						//등록
						dbResult2 = contractMapper.insertContPmBaInfo(contractDto);
					}

					if(dbResult2 > 0) {
						//3.계약-계좌인증히스토리 등록
						//시퀀스 조회
						aahNo = contractMapper.selectSeqContBaAuthH(); //계좌인증고유번호
						//set
						contractDto.setAahNo(aahNo);
						contractDto.setPgCd(pgCd);
						contractDto.setAuthResultCd(authResultCd);
						contractDto.setPmNo(pmNo);
						//등록
						dbResult3 = contractMapper.insertContBaAuthH(contractDto);
					}

					if(dbResult3 > 0) {
						//4.인증 요청
						//set
						saveMap.put("selBank", bankCd);
						saveMap.put("reqNo", aahNo);
						saveMap.put("accountNum", accountNo);
						rtnReqNo = ksnetService.accountCertInsert(saveMap);
						if(!rtnReqNo.equals("")) { //인증 요청 등록 성공이면
							ksnetRetrnMap = new HashMap<String, Object>();
							//5.인증 결과 수신
							ksnetRetrnMap = ksnetService.accountCertInfo(saveMap);
							ksnetResult = ksnetRetrnMap.get("result").toString();	//인증 결과값
							ksnetResultNm = StringUtil.nvl(ksnetRetrnMap.get("recv_name"),""); //인증 결과 예금주명
							if(ksnetResult.equals("1")) { //인증 수신 결과 성공
								contractDto.setDepositorUpYn("Y");
								if(dipositor.equals(ksnetResultNm)) { //입력, 인증 결과 예금주명 같다면
									authResultCd = 2; //성공
									isAuth = 2; //인증완료
									result = "1";//완료
									returnMap.put("pmNo", pmNo);
									contractDto.setDepositor(dipositor);
								}else {
									authResultCd = 0; //실패
									isAuth = 1; //미인증
									result = "-88"; //예금주 명이 다름
									returnMap.put("pmNo", "");
									//예금주명이 다르기 때문에 ""로 변경
									contractDto.setDepositor("");
								}

								//6.계약-계좌인증히스토리 처리결과 코드 수정
								contractDto.setAuthResultCd(authResultCd);
								contractDto.setAahNo(aahNo);
								contractMapper.updateContBaAuthH(contractDto);

								//7.계약-결제수단_은행계좌정보 수정
								contractDto.setIsAuth(isAuth);
								contractDto.setAahNo(aahNo);
								contractDto.setPmNo(pmNo);
								contractMapper.updateContPmBaInfo(contractDto);

								returnMap.put("result", result);


							}else{ //인증 수신 결과 실패
								log.error("ContService > accountCertInfo recv_err_code : " + ksnetResult);
								authResultCd = 0; //실패
								isAuth = 1; //미인증
								//6.계약-계좌인증히스토리 처리결과 코드 수정
								contractDto.setAuthResultCd(authResultCd);
								contractDto.setAahNo(aahNo);
								contractMapper.updateContBaAuthH(contractDto);

								//7.계약-결제수단_은행계좌정보 수정
								contractDto.setIsAuth(isAuth);
								contractDto.setAahNo(aahNo);
								contractDto.setPmNo(pmNo);
								contractMapper.updateContPmBaInfo(contractDto);
								returnMap.put("result", "-99");
								returnMap.put("pmNo", "");
							}

						}else { //인증 요청 등록 등록 실패
							//5.계약-계좌인증히스토리 처리결과 코드 수정
							authResultCd = 0; //실패
							contractDto.setAuthResultCd(authResultCd);
							contractDto.setAahNo(aahNo);
							contractMapper.updateContBaAuthH(contractDto);


							//6.계약-결제수단_은행계좌정보 수정
							isAuth = 1; //미인증
							contractDto.setIsAuth(isAuth);
							contractDto.setAahNo(aahNo);
							contractDto.setPmNo(pmNo);
							contractMapper.updateContPmBaInfo(contractDto);
							returnMap.put("result", "-99");
							returnMap.put("pmNo", "");
							log.error("ContService > accountCertInsert error : " + rtnReqNo);
						}
					}
				}


			}//else 인증 받은 내역이 없을 경우 end

		} catch (Exception e) {
			log.error("ContService > contMethodPmBaAuthInsertProc : " + e.toString());
			throw e;
		}

		return returnMap;

	}//contMethodPmBaAuthInsertProc end




	/**
	 * 계약 등록 처리. 
	 * @author : Lee
	 * @date : 2022. 9. 30.
	 * @param contractDto
	 * @param loginInfo
	 * @throws Exception
	 * @return : Map<String,Object>
	 */
	@Transactional(Tx.MY_BATIS)
	@DataSource(DatabaseType.DB_MARIA_WIPET_SVC)

	public Map<String, Object> contCreateProc(@ModelAttribute("ContractDto") ContractDto contractDto, Optional<LoginInfo> loginInfo) throws Exception {
		LogMdc.name.accept("contract-create");
		Map<String, Object> returnMap = null;
		Map<String, Object> saveMap = null;

		String regMgrId = "";				//등록자ID
		int insuAccCnt = 0; 				//구좌수
		int pdtUnitPrice = 0; 				//상품가격
		//String strPdtUnitPrice = "";		//입력한 상품 금액
		int monthPayAmount = 0; 			//월납입액
		//String strMonthPayAmount = "";		//입력한 월 납입액
		int orginPayTimes = 0; 				//본래 가입납입기간
		String pmNo = ""; 					//출금동의고유번호
		int totalPayAmount = 0; 			//가입금액
		//String strTotalPayAmount = "";		//입력한 가입금액
		String custNm = ""; 				//계약자명
		String mpNo = "";					//계약자 휴대폰
		String birthDate = "";				//계약자 생년월일
		int sex = 0;						//계약자 성별
		int prAreaTypeCd = 0;				//우편물 수령처
		String email = "";					//계약자 이메일 주소
		String contactTelNo = "";			//계약자 전화
		String zipCode = "";				//계약자 우편번호
		String addr = "";					//계약자 기본주소
		String addrDetail = "";				//계약자 상세주소
		int agreeTypeCd1 = 0; 				//필수적 수집, 이용
		int agreeTypeCd3 = 0; 				//필수적 제공
		//List<Integer> agreeTypeCd4 = null; 	//선택적 수집, 이용 매체
		String arrAgreeTypeCd4 = "";		//선택적 수집, 이용 매체
		int agreeTypeCd9 = 0; 				//선택적 제공
		String agentOrdNo = "";				//대리점주분번호
		String channelCd = "";				//채널경로코드
		String recruitMgrCd = "";			//모집자코드
		String pdtCd = "";					//상품코드
		int payTypeCd = 0;					//상품납입기간구분코드
		int discountTimes = 0;				//할인횟수
		int payTimes = 0;					//가입납입기간
		String strBankCd = ""; 				//은행코드(ksnet 은행코드/우리마인즈 은행코드) ex) 120/12
		int bankCd = 0;						//우리마인즈 은행코드
		String accountNo = "";				//계좌번호
		String transferDate = "";			//이체일자
		String transferStartDateYYYY = ""; 	//초회납 개시일(년)
		String transferStartDateMM = ""; 	//초회납 개시일(월)
		String transferStartDateDay = ""; 	//초회납 개시일(일)
		String transferStartDate = "";		//이체개시일(초회납 게시일)
		String depositor = "";				//예금주명
		String relTypeCd = ""; 				//예금주 관계
		int depRelTypeCd = 0;				//예금주관계코드
		String depBirthDate = "";			//예금주생년월일
		String depTelNo = "";				//예금주연락처
		/*
		 * 삼성화재보험, arr 구분값('/')
		 * 보험개시일 경우 관리 필요 없음, 삼성화재에게 펫 가입 정보 전달 후 삼성화재측에서 처리가완료 된후 부터 개시일이 되기 때문에 특정한 날이 없음. 단지 안내 문구로.
		 */
		String sfInsuJoinArr = ""; 		//가입여부 arr
		String petNmArr = "";			//펫 이름 arr
		String petTypeCdArr = "";		//펫 종류/품종 코드 arr
		String petBirthDateArr = "";	//펫 생년월일 arr
		String petSexArr = "";			//펫 성별 arr
		String petRegNoArr = "";		//펫 등록번호 arr

		/*
		* 검증할 상품정보 조회
		*/
		int comparePdtUnitPrice = 0;
		int comparePayTimes = 0;
		int compareMonthPayAmount = 0;
		int fDiscountNumMin = 0;
		int fDiscountNumMax = 0;
		int mDiscountNumMin = 0;
		int mDiscountNumMax = 0;
		int compareTotalPayAmount = 0;
		int time = 150;

		/*계좌 정보*/
		String encAccountNo = ""; //암호화 계좌번호
		int srchIsAuth = 0;	//은행계좌 정보 인증여부(1:미인증, 2:인증완료)
		String[] arrBank = null;
		int dupCnt = 0;
		String dbPmNo = ""; //결제수단고유번호는 계약등록 전에 선등록을 하기 때문에, 이미 pmNo값이 존재함

		/*초회납 개시일*/
		long dateDiff = 0L;
		int limitDate = 14;
		String curYYYMMDay = "";

		int intResult = 0; //등록 결과값
		boolean regFlag = true; //while 등록 flag
		String custNo = ""; //고객고유번호
		int agreeCnt = 7; //고객동의 개수
		int agreeTypeCd = 0;
		int agree = 0;
		int agreeTypeCd5 = 0;
		int agreeTypeCd6 = 0;
		int agreeTypeCd7 = 0;
		int agreeTypeCd8 = 0;
		String [] arrAgreeTypeCd4In = null;
		List<CustAgreeRequestDto> agreeList = null;
		Map<String, Object> agreeMap = null;
		int srchBaCert = 1; //계좌증빙 확인 여부 (1:완료, 2:미완료)
		int baCertCnt = 0;
		int inBaCert = 2; //등록할 계좌증빙 확인 여부 (1:완료, 2:미완료)
		try{
			//외부에서 호출시 로그인 정보가 없음
			if(loginInfo.isEmpty()){
				regMgrId = "";
			}else {
				regMgrId = loginInfo.get().getManagerId();
			}

			/*1.DTO 에서 정보 조회*/
			insuAccCnt = contractDto.getInsuAccCnt(); 						//구좌수
			pdtUnitPrice = contractDto.getPdtUnitPrice(); 					//상품가격
			//strMonthPayAmount = contractDto.getStrPdtUnitPrice();			//입력한 상품 금액(for 검증)
			//strMonthPayAmount = StringUtil.strReplace(strMonthPayAmount, ",", "");
			monthPayAmount = contractDto.getMonthPayAmount(); 				//월납입액
			//strMonthPayAmount = contractDto.getStrMonthPayAmount();			//입력한 월 납입액(for 검증)
			//strMonthPayAmount = StringUtil.strReplace(strMonthPayAmount, ",", "");
			orginPayTimes = contractDto.getOrginPayTimes(); 				//본래 가입납입기간
			pmNo = contractDto.getPmNo(); 									//출금동의고유번호(이미 계좌인증 받은 고객 경우 기존 pmNo값을 받아온다)
			totalPayAmount = contractDto.getTotalPayAmount(); 				//가입금액
			//strTotalPayAmount = contractDto.getStrTotalPayAmount();			//입력한 가입금액(for 검증)
			//strTotalPayAmount = StringUtil.strReplace(strTotalPayAmount, ",", "");
			custNm = contractDto.getCustNm(); 								//계약자명
			mpNo = contractDto.getMpNo();									//계약자 휴대폰
			birthDate = contractDto.getBirthDate();							//계약자 생년월일
			sex = contractDto.getSex();										//계약자 성별
			prAreaTypeCd = contractDto.getPrAreaTypeCd();					//우편물 수령처
			email = contractDto.getEmail();									//계약자 이메일 주소
			contactTelNo = contractDto.getContactTelNo();					//계약자 전화번호
			zipCode = contractDto.getZipCode();								//계약자 우편번호
			addr = contractDto.getAddr();									//계약자 기본주소
			addrDetail = contractDto.getAddrDetail();						//계약자 상세주소
			agreeTypeCd1 = contractDto.getAgreeTypeCd1(); 					//필수적 수집, 이용
			agreeTypeCd3 = contractDto.getAgreeTypeCd3(); 					//필수적 제공
			//agreeTypeCd4 = contractDto.getAgreeTypeCd4(); 				//선택적 수집, 이용 매체
			arrAgreeTypeCd4 = contractDto.getArrAgreeTypeCd4();				//선택적 수집, 이용 매체
			agreeTypeCd9 = contractDto.getAgreeTypeCd9(); 					//선택적 제공
			agentOrdNo = contractDto.getAgentOrdNo();						//대리점주분번호
			channelCd = contractDto.getChannelCd();							//채널경로코드
			recruitMgrCd = contractDto.getRecruitMgrCd();					//모집자코드
			pdtCd = contractDto.getPdtCd();									//상품코드
			payTypeCd = contractDto.getPayTypeCd();							//상품납입기간구분코드
			discountTimes = contractDto.getDiscountTimes();					//할인횟수
			payTimes = contractDto.getPayTimes();							//가입납입기간
			strBankCd = contractDto.getStrBankCd(); 						//은행코드(ksnet 은행코드/우리마인즈 은행코드) ex) 120/12
			arrBank = strBankCd.split("/");
			bankCd = Integer.parseInt(arrBank[1]); 							//우리마인즈 은행코드
			accountNo = contractDto.getAccountNo();							//계좌번호
			transferDate = contractDto.getTransferDate();					//이체일자
			transferStartDateYYYY = contractDto.getTransferStartDateYYYY(); //초회납 개시일(년)
			transferStartDateMM = contractDto.getTransferStartDateMM(); 	//초회납 개시일(월)
			transferStartDateDay = contractDto.getTransferStartDateDay(); 	//초회납 개시일(일)
			transferStartDate = "";											//이체개시일(초회납 게시일)
			depositor = contractDto.getDepositor();							//예금주명
			relTypeCd = contractDto.getRelTypeCd(); 						//예금주 관계
			depRelTypeCd = 0;												//예금주관계코드
			depBirthDate = contractDto.getDepBirthDate();					//예금주생년월일
			depTelNo = contractDto.getDepTelNo();							//예금주연락처
			/*
			 * 삼성화재보험, arr 구분값('/')
			 * 보험개시일 경우 관리 필요 없음, 삼성화재에게 펫 가입 정보 전달 후 삼성화재측에서 처리가완료 된후 부터 개시일이 되기 때문에 특정한 날이 없음. 단지 안내 문구로.
			 */
			sfInsuJoinArr = ""; 	//가입여부 arr
			petNmArr = "";			//펫 이름 arr
			petTypeCdArr = "";		//펫 종류/품종 코드 arr
			petBirthDateArr = "";	//펫 생년월일 arr
			petSexArr = "";			//펫 성별 arr
			petRegNoArr = "";		//펫 등록번호 arr


			//결과 map
			returnMap = new HashMap<String, Object>();

			/*
			 * 2.유효성 검사 및 값 설정
			*/
			//계약자 생년월이 8자리 검사
			if(birthDate.length() != 8){
				returnMap.put("result", "-1");
				return returnMap;
			}

			if(agreeTypeCd1 != 1) { //필수적 수집, 이용 값이 동의 가 아니면
				returnMap.put("result", "-2");
				return returnMap;
			}

			if(agreeTypeCd3 != 1) { //필수적 제공 값이 동의 가 아니면
				returnMap.put("result", "-3");
				return returnMap;
			}

			//데이타소스 변경(서비스내에서 다른 서비스 호출시 기존 데이터 소스를 계속 유지 할 시 정의)
			DatabaseContextHolder.set(DatabaseType.DB_MARIA_WIPET_SVC);
			
			//상품정보조회
			ProductDto productDto = productService.findById(pdtCd);

			comparePdtUnitPrice = productDto.getPdtUnitPrice(); 	//검증할 상품금액
			comparePayTimes = productDto.getPayTimes();				//검증할 가입납입기간
			compareMonthPayAmount = productDto.getMonthPayAmount(); //검증할 월납입액

			fDiscountNumMin = productDto.getFDiscountNumMin(); 	//일시납 할인횟수-최소
			fDiscountNumMax = productDto.getFDiscountNumMax();	//일시납 할인횟수-최대
			mDiscountNumMin = productDto.getMDiscountNumMin();	//월납 할인횟수-최소
			mDiscountNumMax = productDto.getMDiscountNumMax();	//월납 할인횟수-최대

			if(pdtUnitPrice != comparePdtUnitPrice) { //파라메터 넘어온 상품 금액과 DB조회 상품 금액이 다르면
				returnMap.put("result", "-4");
				return returnMap;
			}

			if(monthPayAmount != compareMonthPayAmount) { //파라메터 넘어온 월납입액과 DB조회 월납입액이 다르면
				returnMap.put("result", "-5");
				return returnMap;
			}

			if(payTypeCd == 1){ //일시납
				if(discountTimes > fDiscountNumMax){ //파라메터 넘어온 할인횟수가 일시납 할인횟수-최대보다 크면
					returnMap.put("result", "-6");
					return returnMap;
				}
				compareTotalPayAmount = discountTimes * (comparePdtUnitPrice/time); //가입금액 = 상품금액 - {할인횟수 × (상품금액 ÷ 150)}
				if(totalPayAmount != compareTotalPayAmount) { //파라메터 가입금액과 DB기준 가입금액이 다르면
					returnMap.put("result", "-8");
					return returnMap;
				}
			}else { //월납
				if(discountTimes > mDiscountNumMax){ //파라메터 넘어온 할인횟수가 월납 할인횟수-최대보다 크면
					returnMap.put("result", "-7");
					return returnMap;
				}

				compareTotalPayAmount = (comparePayTimes-discountTimes) * compareMonthPayAmount;	//가입금액 = (납입기간 - 할인횟수) × 월납입액
				if(totalPayAmount != compareTotalPayAmount) { //파라메터 가입금액과 DB기준 가입금액이 다르면
					returnMap.put("result", "-9");
					return returnMap;
				}
			}

			if(payTimes != (comparePayTimes-discountTimes)) { //파라메터 넘어온 가입납입기간과 DB조회 가입납입기간-할인횟수
				returnMap.put("result", "-10");
				return returnMap;
			}

			//결제수단고유번호 여부
			if(pmNo ==	null || pmNo.equals("")) {
				returnMap.put("result", "-11");
				return returnMap;
			}


			// 기존 인증여부 및 pmNo 비교
			AccountCertRequestDto accountCertRequestDto = new AccountCertRequestDto();
			srchIsAuth = 2; //인증완료

			accountCertRequestDto.setIsAuth(srchIsAuth);
			encAccountNo = AES256Util.strEncode(accountNo, Security.AES_SECRET_KEY); //계좌번호 암호화
			accountCertRequestDto.setPopAccountNo(encAccountNo);
			accountCertRequestDto.setPopBankCd(Integer.toString(bankCd));
			
			//데이타소스 변경(서비스내에서 다른 서비스 호출시 기존 데이터 소스를 계속 유지 할 시 정의)
			DatabaseContextHolder.set(DatabaseType.DB_MARIA_WIPET_SVC);
			
			//인증 완료 된 동일 예금주, 은행코드, 계좌번호가 존재 여부
			dupCnt = accountCertMapper.selectContAccountCertCnt(accountCertRequestDto);
			if(dupCnt < 1){
				returnMap.put("result", "-11");
				return returnMap;
			}

			//기존 결제수단고유번호 조회
			dbPmNo = accountCertMapper.selectContAccountCert(accountCertRequestDto);
			if(dbPmNo.equals("") || !pmNo.equals(dbPmNo)) { //DB조회 결제수단고유번호가 "" 이거나 파라메터 넘어온 결제수단고유번호와 다르면
				returnMap.put("result", "-11");
				return returnMap;
			}

			//초회납 개시일 체크
			//현재일
			curYYYMMDay = DateUtil.getDateFmt("yyyyMMdd");

			//선택한 초회납 개시일
			transferStartDate = transferStartDateYYYY+transferStartDateMM+transferStartDateDay;
			dateDiff = DateUtil.diffOfDate(curYYYMMDay, transferStartDate);

			if(dateDiff < 0 || dateDiff > limitDate){ //선택한 초회납 게시일이 0보다 작거나 15일 이상이면
				returnMap.put("result", "-12");
				return returnMap;
			}

			//예금주 생년월일 8자리 검사
			if(depBirthDate.length() != 8){
				returnMap.put("result", "-13");
				return returnMap;
			}
			
			//선택적 수집, 이용 매체 값들
//System.out.println("arrAgreeTypeCd4.lent ==" + arrAgreeTypeCd4.length());			
			if(arrAgreeTypeCd4 == null) {
				returnMap.put("result", "-14");
				return returnMap;
			}
			

			/*3.값 설정*/
			if(payTypeCd == 1) { //상품 납입기간 이 일시납 일 경우
				//monthPayAmount is null
				//payTimes is null
			}
			//납입정보 등록시 출금이체증빙완료여부 pmNo로 증빙 완료된 건이 하나라도 있으면 증빙완료로 등록 해야함.

			
			/*
			 * 3. 등록처리
			 * 계약등록관리, 증서번호 발급관리, 계약자정보, 고객동의, 납입정보, 계약관리, \
			 * */
			try {
				//계약-등록관리
				//생성자 및 set
				ContRegGrpRequestDto contRegGrpRequestDto = new ContRegGrpRequestDto();
				contRegGrpRequestDto.setRegMgrId(regMgrId);
				contRegGrpRequestDto.setInsuAccCnt(insuAccCnt);

				//등록처리
				contractMapper.insertContractRegGrp(contRegGrpRequestDto);
			} catch (Exception e) {
				log.error("ContService > contCreateProc : insertContractRegGrp error " + e.toString());
				returnMap.put("result", "-99");
				return returnMap;
			}
			
			
			//생성자 초기화
			ContCertNoMRequestDto contCertNoMRequestDto = null;
			ContCustInfoRequestDto contCustInfoRequestDto = null;
			CustAgreeRequestDto custAgreeRequestDto = null;
			
			while(insuAccCnt --> 0) { //구좌수 만큼 등록 하기
				try {
					//3-1.계약-증서번호 발급관리
					//생성자 및 set
					contCertNoMRequestDto = new ContCertNoMRequestDto();
					contCertNoMRequestDto.setRegMgrId(regMgrId);
					//등록처리
					contractMapper.insertContCertNoM(contCertNoMRequestDto);
				} catch (Exception e) {
					log.error("ContService > contCreateProc : insertContCertNoM error " + e.toString());
					regFlag = false;
					break;
				}
				
				try {
					//3-2.계약-계약자 정보
					//생성자 및 set
					contCustInfoRequestDto = new ContCustInfoRequestDto();
					contCustInfoRequestDto.setCustNm(custNm);
					contCustInfoRequestDto.setMpNo(mpNo);
					contCustInfoRequestDto.setBirthDate(birthDate);
					contCustInfoRequestDto.setSex(sex);
					contCustInfoRequestDto.setPrAreaTypeCd(prAreaTypeCd);
					if(prAreaTypeCd != 2) { //우편물 수령처가 이메일이 아니면 이메일주소 값 ""
						email = "";
					}
					contCustInfoRequestDto.setEmail(email);
					/*주소 찾기 기능 비활성 상태여서 ""로 셋팅됨*/
					contCustInfoRequestDto.setZipCode(zipCode);
					contCustInfoRequestDto.setAddr(addr);
					contCustInfoRequestDto.setAddrDetail(addrDetail);
					contCustInfoRequestDto.setContactTelNo(contactTelNo);
	
					//등록처리
					contractMapper.insertContCustInfo(contCustInfoRequestDto);
				} catch (Exception e) {
					log.error("ContService > contCreateProc : insertContCustInfo error " + e.toString());
					regFlag = false;
					break;
				}
				
				//고객고유번호
				custNo = contCustInfoRequestDto.getCustNo();
				
				try {
					//3-3.고객동의 
					//생성자 및 set
					//선택적 수집, 이용 매체
					arrAgreeTypeCd4In = arrAgreeTypeCd4.split("/");
					agreeList = new ArrayList<CustAgreeRequestDto>();
					agreeMap = new HashMap<String, Object>();
					
					for(int i=0; i<agreeCnt; i++) {
						custAgreeRequestDto = new CustAgreeRequestDto();
						custAgreeRequestDto.setCustNo(custNo);
						switch(i){
						 case 0:
							 agreeTypeCd = 1; //개인정보 활용 동의 필수적 수집, 이용
							 agree = agreeTypeCd1;
							 break;
						 case 1:
							 agreeTypeCd = 3; //개인정보 활용 동의 필수적 제공
							 agree = agreeTypeCd3;
							 break;
						 case 2:
							 agreeTypeCd = 5; //개인정보 활용 동의 선택적 수집, 이용 매체 전화
							 agree = Integer.parseInt(arrAgreeTypeCd4In[0]);
							 break;
						 case 3:
							 agreeTypeCd = 6; //개인정보 활용 동의 선택적 수집, 이용 매체 문자
							 agree = Integer.parseInt(arrAgreeTypeCd4In[1]);
							 break;
						 case 4:
							 agreeTypeCd = 7; //개인정보 활용 동의 선택적 수집, 이용 매체 이메일
							 agree = Integer.parseInt(arrAgreeTypeCd4In[2]);
							 break;
						 case 5:
							 agreeTypeCd = 8; //개인정보 활용 동의 선택적 수집, 이용 매체 서면
							 agree = Integer.parseInt(arrAgreeTypeCd4In[3]);
							 break; 
						 case 6:
							 agreeTypeCd = 9; //개인정보 활용 동의 선택적 제공
							 agree = agreeTypeCd9;
							 break;	 
						}
						
						custAgreeRequestDto.setAgreeTypeCd(agreeTypeCd);
						custAgreeRequestDto.setAgree(agree);
						agreeList.add(custAgreeRequestDto);
					}//for end
					
					agreeMap.put("list", agreeList); //list add
					
					//등록처리
					contractMapper.insertCustAgree(agreeMap);
					
				} catch (Exception e) {
					log.error("ContService > contCreateProc : insertCustAgree error " + e.toString());
					regFlag = false;
					break;
				}
				
				
				
				//ContPayInfoRequestDto 생성자
				ContPayInfoRequestDto contPayInfoRequestDto = new ContPayInfoRequestDto();
				try {
					//3-4.계좌증빙 받은 납입정보 카운트 조회
					//set
					contPayInfoRequestDto.setPmNo(pmNo);
					contPayInfoRequestDto.setBaCert(srchBaCert);
					
					baCertCnt = contractMapper.selectContPayInfoBaCert(contPayInfoRequestDto);
					if(baCertCnt > 0) { //넘어온 결제수단고유번호로 이미 계좌증빙 받은 납입정보가 있음
						inBaCert = 1; //다시 증빙을 ksnet에 받지 않기 위해 완료료 등록
					}else {
						inBaCert = 2; //최초 등록이거나, 아직 증빙 하지 않은 상태는 미완료로 등록
					}
				}catch(Exception e) {
					log.error("ContService > contCreateProc : selectContPayInfoBaCert error " + e.toString());
					regFlag = false;
					break;
				}
				
				try {
					//3-5.납입정보 등록
					//set
					contPayInfoRequestDto.setBaCert(inBaCert);
					contPayInfoRequestDto.setTransferDate(transferDate);
					contPayInfoRequestDto.setTransferStartDate(transferStartDate);
					
					//등록처리
					contractMapper.insertContPayInfo(contPayInfoRequestDto);
				}catch(Exception e) {
					log.error("ContService > contCreateProc : insertContPayInfo error " + e.toString());
					regFlag = false;
					break;
				}
				
				
				
				
				
			}//while end
			
			//while 등록처리 중 오류 발생시
			if(!regFlag){
				returnMap.put("result", "-99");
				return returnMap;
			}
			
			
			
			/*
			 * 5. 등록처리
			 * 펫정보
			 * */
			
			/*
			 * 6. 수정처리
			 * 결제수단_은행계좌정보
			 * */

			


			returnMap.put("result", "1"); //성공
			return returnMap;

		} catch (Exception e) {
			log.error("ContService > contCreateProc : " + e.toString());
			//returnMap.put("result", "-99");
			//return returnMap;
			throw e;
		}
	}//contCreateProc end


}
