package com.tenminds.domain.contract.model.request;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


/**
 * com.tenminds.domain.contract.model.request
 * ContArsPayAgreeHRequestDto.java

 * Description : 계약 ARS출금동의 히스토리 request DTO<br>
 * Date : 2022. 10. 8.<br>
 * History :<br>
 * - 작성자 : Lee, 날짜 : 2022. 10. 8., 설명 : 최초작성<br>
 *
 * @author Lee
 * @version 1.0
 */
@Setter
@Getter
@NoArgsConstructor
@ToString
public class ContArsPayAgreeHRequestDto {
	
	private String arsPaNo;					//출금동의고유번호
	
	private String subscDate;				//청약일자

	private String custNm;					//계약자명
	
	private String pdtCd;					//상품코드(FK)
	
	private int payTimes;					//가입납입기간
	
	private int totalPayAmount;				//가입금액
	
	private String transferDate;			//이체일자
	
	private int arsResultCd;				//동의결과코드(1:요청중, 2:요청중 실패, 3:요청완료, 4:요청후 실패, 5:동의함, 6:동의 안함)
	
	private String managerId;				//관리자ID(FK)
	
	private String pmNo;					//결제수단고유번호(FK)
	
	private String contractNo;				//계약고유번호(FK)
}
