package com.tenminds.domain.contract.model.request;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


/**
 * com.tenminds.domain.contract.model.request
 * ContArsPaContractRequestDto.java

 * Description : 계약 ARS출금동의 계약목록 request DTO<br>
 * Date : 2022. 10. 8.<br>
 * History :<br>
 * - 작성자 : Lee, 날짜 : 2022. 10. 8., 설명 : 최초작성<br>
 *
 * @author Lee
 * @version 1.0
 */
@Setter
@Getter
@NoArgsConstructor
@ToString
public class ContArsPaContractRequestDto {
	
	private String arsPaNo;					//출금동의고유번호(FK)
	
	private String contractNo;				//계약고유번호(FK)
}
