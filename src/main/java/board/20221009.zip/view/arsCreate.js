$(function(){
	var ars = {
		init: function () {
	        var _this = this;
	        var f = $("form[name='frm']");
	        var crGrpNoAttr = $("input[name='crGrpNo']"); 		//계약고유번호 attr.
	        var crGrpNoAttr = $("input[name='pmNo']"); 			//계약고유번호 attr.
	        var crGrpNoAttr = $("input[name='urlType']"); 		//계약고유번호 attr. 
	        var crGrpNoAttr = $("input[name='contractNo']"); 	//계약고유번호 attr.
			
			//취소 버튼 클릭시
			$(".cancel").off("click.cancel").on("click.cancel",function(e){
				alert("개발중");
			});
			
			//ars 버튼 클릭시
			$(".arsAgree").off("click.arsAgree").on("click.arsAgree",function(e){
				if(confirm('ARS출금동의 진행 하시겠습니까?')){
					_this._contArs(f);
				}
				
			});
	      
		},
		_contArs: function(f){
			var url ="/ext/contract/contArsProc-ajax";
			var data =  $(f).serialize();
			var result;
			$.ajax({
				type : "POST",
				url : url,
				data : data,
				dataType: "json",
				success : function(data){
/*
console.log("data.result : " + data.result);
console.log("data.urlType : " + data.urlType);						
console.log("data.resInfo : " + data.certNos);	
*/					result = data.result;


console.log("result : " + result);
					
		
				},beforeSend:function(){
	            	showLoading();
	            },complete:function(){
	            	hideLoading();
	            },error: function(xhr, status, err) {
		
					//var err = JSON.parse(xhr.responseText);
					//alert(err.message);
		
	            	if (xhr.status == 401) {
	    				alert("접근 권한이 없습니다. 로그인후 다시 시도해 주세요.");
	    			} else if (xhr.status == 403) {
	    				alert("해당 페이지에 대한 권한이 없습니다.");
	    			} else if (xhr.status == 301) {
	    				alert("세션이 끊겼습니다.다시 로그인 해주세요.");
	    				//alert("접근 오류가 발생했습니다. 로그인후 다시 시도해 주세요.");
	    				//location.href = "/";
	    			}else {
	    				alert("처리중 오류가 발생하였습니다. 잠시후 다시 시도해 주세요.");
	    			}
	    			hideLoading();
	            }
			});//ajax end		
		}
	};

	ars.init();
});

