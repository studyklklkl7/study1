$(function(){
	var cont = {
		init: function () {
	        var _this = this;
	        //var f = $('form')[0];
	        var f = $("form[name='frm']");
	        
	      	$("[name='recruitMgrCd']").select2(); //모집자
	      	$("[name='popBankCd']").select2(); //계좌인증 은행(명)코드
	      	$(".petTypeCdSel").select2(); //펫종류,품종
	      	
	      	
	        //구좌수 선택
			//익일 선택하기	
			var insuAccCnt = $("[name='insuAccCnt']").val();
			$("select[name='selAccCnt']").find("option").each (function (index, item) {
				var val = $(item).val();
				if(insuAccCnt == val){
					$(item).attr("selected", "selected");
				}
			});
	        $("select[name='selAccCnt']").attr("disabled", "disabled"); //구좌수 disabled
	        
	        //우편번호 찾기
	        $("#zipCode, #addr, #zipCodeBtn").off("click.zipcode").on("click.zipcode",function(e){
				openDaumPostcode();
			});
			
			//(선택) 광고성 정보 수신 동의 선택
			$("input[name='agreeTypeCd99']").off("click.agreeTypeCd99").on("click.agreeTypeCd99",function(e){
				var val = $(this).val();
				if(val == "2"){ //동의 안함
					//매체 모두 비선택
					$("input:checkbox[name='agreeTypeCd4']").prop('checked', false);
				}
			});
				
			//(선택) 광고성 정보 수신 동의 > 매체 선택시
			$("input[name='agreeTypeCd4']").off("click.agreeTypeCd4").on("click.agreeTypeCd4",function(e){
				var chkFlag = false; 				
				$("input[name='agreeTypeCd4']").each(function (index, item) {
					
					if($(item).is(":checked")==true){
						chkFlag = true;
						return false;

					}else{
						chkFlag = false;
					}
				});				
				if(chkFlag){
					$("input:radio[name='agreeTypeCd99']:radio[value='1']").prop('checked', true); // 선택하기
				}else{
					$("input:radio[name='agreeTypeCd99']:radio[value='2']").prop('checked', true); // 선택하기
				}
			});
			
			
			
			//채널경로, 모집자 selected
			$("select[name='channelCd'], select[name='recruitMgrCd']").find("option").each (function (index, item) {
				var val = $(item).val();
				var selName = $(this).parent().attr("name");
				var selVal;
							
				if(selName == "channelCd"){ //채널경로
					selVal = chVal;
				}else{//모집자
					selVal = reMrgCdVal;
				}	
				
				if(selVal == val){
					$(item).attr("selected", "selected");
					$(item).val(val).trigger('change');
				}
			});
			
			//모집자 선택시 모집코드 넣기
			$("#recruitMgrCd").off("change.recruitMgrCd").on("change.recruitMgrCd",function(e){
				var val = $(this).val();
				_this._srchRecruitMgrId(f, val);
			});
			
			//브랜드 선택시 상품 동적 구성
	        $(".srchBrandCd").off("change.srchBrandCd").on("change.srchBrandCd",function(e){
				var val = $(this).val();
				_this._srchPdt(f, val);
			});
			
			//상품 선택시 상품정보 가져오기
	        $(".srchPdtCd").off("change.srchPdtCd").on("change.srchPdtCd",function(e){
				var val = $(this).val();
				_this._srchPdtInfo(f, val);
			});
			
			//상품납입기간 선택시
			$("input[name='payTypeCd']:radio").off("change.payTypeCd").on("change.payTypeCd",function(e){
				var val = $(this).val();
				_this._payTypeCdChange(f, val);
			});
			
			//할인횟수 선택시
	        $("#discountTimes").off("change.discountTimes").on("change.discountTimes",function(e){
				var val = $(this).val();
				_this._discountTimesChange(f, val);
			});
			
			//계좌인증 클릭시
			$(".accountCertify").off("click.accountCertify").on("click.accountCertify",function(e){	
				e.preventDefault();
				$(".accountCertPop").modal(); //모달 팝업
					
				var custNm = $("input[name='custNm']").val(); //계약자명
				if(custNm != ""){
					$("input[name='popDepositor']").val(custNm);
				}
				$("select[name='popBankCd']").val('').trigger('change');; //이체 은행명 리셋
				$("input[name='popAccountNo']").val(''); //계좌번호 리셋
			});

			/*계좌인증 팝업*/
			//본인 check, uncheck
			$("input[name='popDepRelTypeCd']").off("change.popDepRelTypeCd").on("change.popDepRelTypeCd",function(e){
				var custNm = $("input[name='custNm']").val(); //계약자명
				var popDepositorAttr = $("input[name='popDepositor']"); //팝업 계약자명 attr
		        if($(this).is(":checked")){
		            $(popDepositorAttr).attr("readonly", true);
		            $(popDepositorAttr).val(custNm);
		            
		        }else{
		            $(popDepositorAttr).attr("readonly", false);
		            $(popDepositorAttr).val('');
		        }
		    });
		    
		    //팝업 계좌인증 버튼 클릭 시
	        $(".popAccCert").off("click.popAccCert").on("click.popAccCert",function(e){
				var certf = $("form[name='accountFrm']");
				if(!inputNameCheck("popDepositor", "예금주명을 입력해주세요.")) return;
				if(!selectNameCheck("popBankCd", "자동이체 은행명을 선택해주세요.")) return;
				if(!inputNameCheck("popAccountNo", "계좌번호를 입력해주세요.")) return;
				_this._accountNoCert(certf);
			});
			/*계좌인증 팝업*/
			
			
			//초회납 개시일 '일' 선택시 
	        /*$(".dayConfirm").off("click.dayConfirm").on("click.dayConfirm",function(e){
				e.preventDefault();
				if(!selectNameCheck("transferStartDateYYYY", "초회납 개시일을 선택해주세요.")) return;
				if(!selectNameCheck("transferStartDateMM", "초회납 개시일을 선택해주세요.")) return;
				if(!selectNameCheck("transferStartDateDay", "초회납 개시일을 선택해주세요.")) return;
				var transferStartDateYYYY = $("select[name='transferStartDateYYYY']").val();
				var transferStartDateMM = $("select[name='transferStartDateMM']").val();
				var transferStartDateDay = $("select[name='transferStartDateDay']").val(); 
				_this._daySelectConfirm(transferStartDateYYYY, transferStartDateMM, transferStartDateDay);
				
			});*/
			
			//초회납 개시일 '일' 선택시 
			$(".dayConfirm").off("change.dayConfirm").on("change.dayConfirm",function(e){
				if(!selectNameCheck("transferStartDateYYYY", "초회납 개시일(년)을 선택해주세요.")) return;
				if(!selectNameCheck("transferStartDateMM", "초회납 개시일(월)을 선택해주세요.")) return;
				if(!selectNameCheck("transferStartDateDay", "초회납 개시일(일)을 선택해주세요.")) return;
				var transferStartDateYYYY = $("select[name='transferStartDateYYYY']").val();
				var transferStartDateMM = $("select[name='transferStartDateMM']").val();
				var transferStartDateDay = $("select[name='transferStartDateDay']").val(); 
				_this._daySelectConfirm(transferStartDateYYYY, transferStartDateMM, transferStartDateDay);				
			});
			
			
			//펫정보 리스트 title 변경
			/*var addIndex;
			$(".petInfoIndex").each (function (index, item) {
				addIndex = index + 1;
				$(item).html('').html("펫 정보_"+addIndex);
			});*/
			
			//펫 선택시 가입 불가 혹은 가능 
	        $(".petTypeCdSel").off("change.petTypeCdSel").on("change.petTypeCdSel",function(e){
				var val = $(this).val();
				var text = $(this).find("option:selected").text();
				var valAttr = $(this).find("option:selected").attr("data-joinable");//1:삼성화재 보험 가입가능 2:불가능
				_this._petSelectTypeJoin($(this), valAttr, text);
			});
			
			//삼성화재보험 가입 선택시
			$("input:radio[name^='sfInsuJoin_']").off("click.sfInsuJoin").on("click.sfInsuJoin",function(e){
				var val = $(this).val();
				if(val == "1"){ //가입 선택 경우
					alert("삼성화재보험 가입을 위해\n펫 정보 일체를 정확히 입력해 주세요.");
				}
				if(val == "2"){//미가입 선택 경우
					petInfoReset($(this)); //펫정보 reset
				}
			});
	
			//등록버튼 클릭시
			$(".save").off("click.save").on("click.save",function(e){
				var checkedPrAreaTypeCd =  $("input:radio[name='prAreaTypeCd']:checked").val(); //선택한 우편물 수령처
				var mpNo = $("input[name='mpNo']").val();
				var birthDate = $("input[name='birthDate']").val();
				var checkedPayTypeCd =  $("input:radio[name='payTypeCd']:checked").val(); //상품납입 기간
				var email =  $("input[name='email']").val();
				var agreeTypeCd1 =  $("input:radio[name='agreeTypeCd1']:checked").val(); //필수적 수집, 이용
				var agreeTypeCd1Checked =  $("input:radio[name='agreeTypeCd1']:checked");
				var agreeTypeCd3Checked =  $("input:radio[name='agreeTypeCd3']:checked");
				var agreeTypeCd99Checked =  $("input:radio[name='agreeTypeCd99']:checked");
				var agreeTypeCd9Checked =  $("input:radio[name='agreeTypeCd9']:checked");
				var agreeTypeCd4Checked = $("input:checkbox[name='agreeTypeCd4']:checked");
				var depBirthDate = $("input[name='depBirthDate']").val();
				var depTelNo = $("input[name='depTelNo']").val();
				var arrAgreeTypeCd4 = $("input[name='arrAgreeTypeCd4']");
				/*계약자 정보 */
				if(!inputNameCheck("custNm", "계약자명을 정확히 입력해 주세요.")) return;
				if(!inputNameCheck("mpNo", "계약자 휴대폰 번호를 정확히 입력해 주세요.")) return;
				if(!vldtHpNo(mpNo)){
					alert("계약자 휴대폰 번호를 정확히 입력해 주세요.");       
					return;    
				}
				if(!inputNameCheck("birthDate", "생년월일/성별을 정확히 입력해 주세요.")) return;
				if(birthDate.length !=8){ //8자리
					alert("생년월일/성별을 정확히 입력해 주세요.");
					return;
				}  
				if(!inputRadioNameCheck("sex", "생년월일/성별을 정확히 입력해 주세요.")) return;  
				if(!inputRadioNameCheck("prAreaTypeCd", "우편물 수령처를 선택해 주세요.")) return;
				if(checkedPrAreaTypeCd == "2"){ //이메일 체크시 
					if(!vldtEmail(email)){
						alert("이메일 주소를 정확히 입력해 주세요.");       
						return;    
					}
				}
				
				/*개인정보 활용 동의*/
				//(필수) 개인정보의 수집 및 이용 동의
				if(agreeTypeCd1Checked.length == 0){
					alert("(필수) 개인정보 수집 및 이용 동의에 대해 선택해 주세요.");
					return;
				}
				//(선택) 마케팅 활용 동의
				if(agreeTypeCd3Checked.length == 0){
					alert("(선택) 마케팅 활용 동의에 대해 선택해 주세요.");
					return;
				}
				//(선택) 광고성 정보 수신 동의
				if(agreeTypeCd99Checked.length == 0){
					alert("(선택) 광고성 정보 수신 동의에 대해 선택해 주세요.");
					return;
				}
				//(선택) 제3자 제공동의
				if(agreeTypeCd9Checked.length == 0){
					alert("(선택) 제3자 제공 동의에 대해 선택해 주세요.");
					return;
				}
				
				if(agreeTypeCd1 == "2"){ //필수적 수집, 이용 동의 안함이면
					alert("(필수) 개인정보의 수집 및 이용에 대해 ‘동의 안 함’ 시 계약 등록이 불가합니다.");       
					return;
				}
				
				if(agreeTypeCd99Checked.val() == "1"){ //광고성 정보수신동의 동의로 선택시
					if(agreeTypeCd4Checked.length == 0){
						alert("(선택) 광고성 정보 수신 동의 '동의' 로 선택시 매체 선택을 하셔야 합니다.");
						return;
					}
				}
				
				/*계약 기본정보 */
				if(!selectNameCheck("channelCd", "채널경로를 선택해 주세요.")) return;  
				if(!selectNameCheck("recruitMgrCd", "모집자를 선택해 주세요.")) return;
				
				/*상품 및 납입 정보*/
				if(!selectNameCheck("brandCd", "상품 브랜드를 선택해 주세요.")) return;
				if(!selectNameCheck("pdtCd", "상품명을 선택해 주세요")) return;
				
				if(!inputNameCheck("pdtUnitPrice", "상품금액을 입력해 주세요")) return;
				if(!inputRadioNameCheck("payTypeCd", "상품납입기간을 선택해 주세요")) return;
				if(checkedPayTypeCd == "2"){ //월납일 경우에만
					if(!inputNameCheck("strMonthPayAmount", "월납입액을 입력해 주세요")) return;
					if(!inputNameCheck("strPayTimes", "가입납입기간을 입력해 주세요")) return;
				}
				
				if(!selectNameCheck("discountTimes", "할인횟수를 선택해 주세요.")) return;
				if(!inputNameCheck("strTotalPayAmount", "가입금액을 입력해 주세요.")) return;
				if(!selectNameCheck("selAccCnt", "구좌수를 선택해 주세요.")) return;
				if(!inputNameCheck("pmNo", "계좌인증을 진행해주세요.")) return;
				if(!selectNameCheck("strBankCd", "자동이체 은행명을 선택해주세요.")) return;
				if(!inputNameCheck("accountNo", "계좌번호를 입력해주세요.")) return;
				if(!selectNameCheck("transferDate", "이체일자를 선택해 주세요.")) return;
				if(!selectNameCheck("transferStartDateYYYY", "초회납 개시일을 선택해 주세요.")) return;
				if(!selectNameCheck("transferStartDateMM", "초회납 개시일을 선택해 주세요.")) return;
				if(!selectNameCheck("transferStartDateDay", "초회납 개시일을 선택해 주세요.")) return;
				if(!inputNameCheck("depositor", "예금주명을 입력해 주세요.")) return;
				if(!selectNameCheck("relTypeCd", "예금주 관계를 선택해 주세요.")) return;
				if(!inputNameCheck("depBirthDate", "예금주 생년월일(*숫자 8자리)을 정확히 입력해 주세요.")) return;
				if(depBirthDate.length !=8){ //8자리
					alert("예금주 생년월일(*숫자 8자리)을 정확히 입력해 주세요.");
					return;
				}
				if(!inputNameCheck("depTelNo", "예금주 연락처를 정확히 입력해 주세요.")) return;
				if(!vldtTelNo(depTelNo)){
					alert("예금주 연락처를 정확히 입력해 주세요.");       
					return;    
				}
				
				//고객 동의 선택적 수집, 이용 매체
				var agreeCnt = 0;
				var agreeVal, areeValArr;
				$("input[name='agreeTypeCd4']").each (function (index, item) {
					if($(item).is(":checked")==true){
						agreeVal = 1;

					}else{
						agreeVal = 2;
					}
					if(agreeCnt == 0){
						areeValArr = agreeVal;
					}else{
						areeValArr = areeValArr + "/" + agreeVal;
					}
					agreeCnt++;
				});
				$(arrAgreeTypeCd4).val(areeValArr);
				
				/*펫 정보*/
				var sfInsuJoinArr = "";
				var petNmArr = "";
				var petTypeCdArr = ""; 
				var petBirthDateArr = "";
				var petSexArr = ""; 
				var petRegNoArr = "";
				var chkCnt = 0;
				var saveFlag = true;
				$(".petformTable").each (function (index, item) {
					index ++;
					var petTabletitle = $(item).find(".petTableTitle").html();
					var sfInsuJoin = $(item).find("input:radio[name=sfInsuJoin_"+index+"]:checked").val();
					var petNm = $(item).find("input[name=petNm_"+index+"]").val();
					var petTypeCd = $(item).find("select[name=petTypeCd_"+index+"]").val();
					var petBirthDate = $(item).find("input[name=petBirthDate_"+index+"]").val();
					var petSex = $(item).find("input:radio[name=petSex_"+index+"]:checked").val();
					var petRegNo = $(item).find("input[name=petRegNo_"+index+"]").val();
					
					if(sfInsuJoin == "1"){ //삼서화재보험 가입 할 경우
						if(!objInputNameCheck($(item), index, "petNm_", petTabletitle+"의 펫 이름을 정확히 입력해 주세요.")){
							saveFlag = false;
							return false;
						} 
						if(!objSelectNameCheck($(item), index, "petTypeCd_", petTabletitle+"의 펫 종류/품종을 선택해 주세요.")){
							saveFlag = false;
							return false;
						}
						if(!objInputNameCheck($(item), index, "petBirthDate_", petTabletitle+"의 펫 생년월일(*숫자 8자리)을 정확히 입력해 주세요.")){
							saveFlag = false;
							return false;
						}
						if(petBirthDate.length != 8){
							alert("펫 생년월일(*숫자 8자리)을 정확히 입력해 주세요.");
							saveFlag = false;
							return false;	
						}
						if(!objInputRadioNameCheck($(item), index, "petSex_", petTabletitle+"의 펫 성별을 선택해 주세요.")){
							saveFlag = false;
							return false;
						}
						if(!objInputNameCheck($(item), index, "petRegNo_", petTabletitle+"의 펫 등록번호(*숫자 15자리)를 정확히 입력해 주세요.")){
							saveFlag = false;
							return false;
						}
						if(petRegNo.length != 15){
							alert("펫 등록번호(*숫자 15자리)를 정확히 입력해 주세요.");
							saveFlag = false;	
							return false;
						}
					}//if end
					
				
					sfInsuJoinArr = sfInsuJoinArr == "" ? sfInsuJoin : sfInsuJoinArr + "/" + sfInsuJoin;
					if(typeof petSex == "undefined"){
						petSex = "0"; //'0'은 초기화값 백단에서 ""로 DB 등록
					}
					if(petNm == "")petNm = "0";
					if(petTypeCd == "")petTypeCd = "0";
					if(petBirthDate == "")petBirthDate = "0";
					if(petRegNo == "")petRegNo = "0";
				
					if(chkCnt == 0){
						petNmArr = petNm;
						petTypeCdArr = petTypeCd;
						petBirthDateArr = petBirthDate;
						petSexArr = petSex;
						petRegNoArr = petRegNo;
					}else{
						petNmArr = petNmArr + "/" + petNm;
						petTypeCdArr = petTypeCdArr + "/" + petTypeCd;
						petBirthDateArr = petBirthDateArr + "/" + petBirthDate;
						petSexArr = petSexArr + "/" + petSex;
						petRegNoArr = petRegNoArr + "/" + petRegNo;
					}

					chkCnt++;

				}); //$(".petformTable").each end

				$("input[name='sfInsuJoinArr']").val(sfInsuJoinArr);
				$("input[name='petNmArr']").val(petNmArr);
				$("input[name='petTypeCdArr']").val(petTypeCdArr);
				$("input[name='petBirthDateArr']").val(petBirthDateArr);
				$("input[name='petSexArr']").val(petSexArr);
				$("input[name='petRegNoArr']").val(petRegNoArr);
				
				//disabled 처리된거 삭제 하기(: 구좌수, 자동이체 은행명, 이체일자, 초회납 개시일, 예금주 관계, 계약자 기본/상세주소)
				$("[class$=disableYN]").each (function (index, item) {
					$(item).attr("disabled", false);
				});				
				$("[class$=disableN]").each (function (index, item) {
					$(item).attr("disabled", false);
				});
				$("[class$=disableChk]").each (function (index, item) {
					$(item).attr("disabled", false);
				});
				
				if(saveFlag){
					_this._contSave(f);	
				}
				
				
			});//click.save end

		},
		_srchRecruitMgrId: function(f, val){
			var recruitMgrKeyAttr = $("input[name='recruitMgrKey']");
			var url ="/ext/contract/recruitMgrInfo-ajax";
			var data =  {recruitMgrCd : val};
			$.ajax({
				type : "POST",
				url : url,
				data : data,
				dataType: "json",
				success : function(result){
					if(result){
						recruitMgrKeyAttr.val(result+"("+val+")");
					}
				},beforeSend:function(){
	            	showLoading();
	            },complete:function(){
	            	hideLoading();
	            },error: function(xhr, status, err) {
	            	if (xhr.status == 401) {
	    				alert("접근 권한이 없습니다. 로그인후 다시 시도해 주세요.");
	    			} else if (xhr.status == 403) {
	    				alert("해당 페이지에 대한 권한이 없습니다.");
	    			} else if (xhr.status == 301) {
	    				alert("세션이 끊겼습니다.다시 로그인 해주세요.");
	    				//alert("접근 오류가 발생했습니다. 로그인후 다시 시도해 주세요.");
	    				//location.href = "/";
	    			}else {
	    				alert("처리중 오류가 발생하였습니다. 잠시후 다시 시도해 주세요.");
	    			}
	    			hideLoading();
	            }
			});//ajax end		
		},
		_srchPdt: function(f, val){
			var url ="/ext/contract/productList-ajax";
			var data =  {brandCd : val};
			$.ajax({
				type : "POST",
				url : url,
				data : data,
				dataType: "json",
				success : function(array){
					if (array.length > 0) {
						$.each(array, function(i, item){
							var optionStr = "<option value=" + item.pdtCd + ">" + 
												 item.pdtName + 
											"</option>";
							
							$("#pdtCd").append(optionStr);
						})
					} else {
						$("#pdtCd").html('').append("<option value=''>선택</option>");
					}
				},beforeSend:function(){
	            	showLoading();
	            },complete:function(){
	            	hideLoading();
	            },error: function(xhr, status, err) {
	            	if (xhr.status == 401) {
	    				alert("접근 권한이 없습니다. 로그인후 다시 시도해 주세요.");
	    			} else if (xhr.status == 403) {
	    				alert("해당 페이지에 대한 권한이 없습니다.");
	    			} else if (xhr.status == 301) {
	    				alert("세션이 끊겼습니다.다시 로그인 해주세요.");
	    				//alert("접근 오류가 발생했습니다. 로그인후 다시 시도해 주세요.");
	    				//location.href = "/";
	    			}else {
	    				alert("처리중 오류가 발생하였습니다. 잠시후 다시 시도해 주세요.");
	    			}
	    			hideLoading();
	            }
			});//ajax end		
		},
		_srchPdtInfo: function(f, val){
			var url ="/ext/contract/productInfo-ajax";
			var data =  {pdtCd : val};
			$.ajax({
				type : "POST",
				url : url,
				data : data,
				dataType: "json",
				success : function(result){				
					if(result){
/*
console.log("result.pdtName ==" + result.pdtName);
console.log("result.pdtDescript ==" + result.pdtDescript);
console.log("result.pdtUnitPrice ==" + result.pdtUnitPrice);
console.log("result.strPdtUnitPrice ==" + result.strPdtUnitPrice);
console.log("result.payTimes ==" + result.payTimes);
console.log("result.strMonthPayAmount ==" + result.strMonthPayAmount);
console.log("result.fDiscountNumMin ==" + result.fDiscountNumMin);
console.log("result.fDiscountNumMax ==" + result.fDiscountNumMax);
console.log("result.mDiscountNumMin ==" + result.mDiscountNumMin);
console.log("result.mDiscountNumMax ==" + result.mDiscountNumMax);
*/
						if(typeof result.pdtName != "undefined"){ //상품 이름 없다면, 모든 정보도 없다
							$(".pdtInfo").find(".pdtName").html('').append(result.pdtName);
							$(".pdtInfo").find(".pdtDescript").html('').append(result.pdtDescript);
							$("input[name='pdtUnitPrice']").val(result.pdtUnitPrice);
							$("input[name='strPdtUnitPrice']").val(result.strPdtUnitPrice);
							
							$(".payTypeCdMonth").html('').append('월납('+result.payTimes+'회)');
							$("input[name='orginPayTimes']").val(result.payTimes);//원래 상품 납입 횟수를 넣어둠
							
							$("input[name='strMonthPayAmount']").val(result.strMonthPayAmount);
							$("input[name='monthPayAmount']").val(result.monthPayAmount);
							
							$("input[name='fDiscountNumMin']").val(result.fDiscountNumMin);
							$("input[name='fDiscountNumMax']").val(result.fDiscountNumMax);
							$("input[name='mDiscountNumMin']").val(result.mDiscountNumMin);
							$("input[name='mDiscountNumMax']").val(result.mDiscountNumMax);
							
							/*
							var mDiscountNumMin = result.mDiscountNumMin;
							var mDiscountNumMax = result.mDiscountNumMax;
									
							if(typeof result.mDiscountNumMin == "undefined" || mDiscountNumMax < 1){
								$("#discountTimes").html('').append("<option value=''>선택</option>");
								$("input[name='payTimes']").val('');
							}else{
								for(var i= mDiscountNumMin; i<=mDiscountNumMax; i++){
									var optionStr = "<option value=" + i + ">" + 
													 i + 
												"</option>";
								
									$("#discountTimes").append(optionStr);
								}
							}
							*/
						}else{
							_pdtInfoReset(); //상품정보 리셋
						}
							
					}
				},beforeSend:function(){
	            	showLoading();
	            },complete:function(){
	            	hideLoading();
	            },error: function(xhr, status, err) {
	            	if (xhr.status == 401) {
	    				alert("접근 권한이 없습니다. 로그인후 다시 시도해 주세요.");
	    			} else if (xhr.status == 403) {
	    				alert("해당 페이지에 대한 권한이 없습니다.");
	    			} else if (xhr.status == 301) {
	    				alert("세션이 끊겼습니다.다시 로그인 해주세요.");
	    				//alert("접근 오류가 발생했습니다. 로그인후 다시 시도해 주세요.");
	    				//location.href = "/";
	    			}else {
	    				alert("처리중 오류가 발생하였습니다. 잠시후 다시 시도해 주세요.");
	    			}
	    			hideLoading();
	            }
			});//ajax end		
		},
		_payTypeCdChange: function(f, val){
			var orginPayTimesVal = $("input[name='orginPayTimes']").val(); //납입횟수
			var discountTimesVal = $("select[name='discountTimes']").val(); //할인횟수
			var pdtUnitPriceVal = $("input[name='pdtUnitPrice']").val();	//상품금액
			var monthPayAmountVal = $("input[name='monthPayAmount']").val();	//월납입액
			
			var fDiscountNumMin = $("input[name='fDiscountNumMin']").val();
			var fDiscountNumMax = $("input[name='fDiscountNumMax']").val();
			var mDiscountNumMin = $("input[name='mDiscountNumMin']").val();
			var mDiscountNumMax = $("input[name='mDiscountNumMax']").val();
			
			var payTimes, strTotalPayAmountVal;
			var times = 150;
			
			$("input[name='strPayTimes']").val(''); //가입납입기간 초기화
			$("input[name='strTotalPayAmount']").val(''); //가입금액 초기화
			$("input[name='payTimes']").val(''); //가입납입기간 초기화
			$("input[name='totalPayAmount']").val(''); //가입금액 초기화
			if(val == "2"){ //월납일 경우
				$(".mpayamountYN").show();	//월납입액 입력필드 노출
				$(".payTimesYN").show();	//가입납입기간 입력필드 노출
				/*if(discountTimesVal != ""){
					payTimes = orginPayTimesVal - discountTimesVal; //가입납입기간
					$("input[name='payTimes']").val(payTimes);
					strTotalPayAmountVal = payTimes * monthPayAmountVal; //가입금액 = 가입납입기간 * 월납입액
					$("input[name='strTotalPayAmount']").val(strTotalPayAmountVal);
				}else{
					$("input[name='payTimes']").val(''); //초기화
					$("input[name='strTotalPayAmount']").val(''); //초기화
				}*/
				if(mDiscountNumMin != "" && mDiscountNumMax != ""){
					$("#discountTimes").html('').append("<option value=''>선택</option>"); //할인횟수 '선택'으로 초기화
					for(var i= mDiscountNumMin; i<=mDiscountNumMax; i++){
						var optionStr = "<option value=" + i + ">" + 
										 i + 
									"</option>";
					
						$("#discountTimes").append(optionStr);
					}
				}else{
					$("#discountTimes").html('').append("<option value=''>선택</option>"); //할인횟수 '선택'으로 초기화
					$("input[name='strPayTimes']").val(''); //가입납입기간 ''초기화
					$("input[name='payTimes']").val(''); //가입납입기간 초기화
				}
			}else{ //일시납일 경우
				$(".mpayamountYN").hide();	//월납입액 입력필드 비노출
				$(".payTimesYN").hide(); //가입납입기간 입력필드 비노출
				
				/*if(discountTimesVal != ""){	 //선택된 할인 횟수 값이 있을 경우		
					strTotalPayAmountVal = pdtUnitPriceVal - (discountTimesVal * (pdtUnitPriceVal/times));	//가입금액 =  상품금액 - {할인횟수 × (상품금액 ÷ 150)}
					$("input[name='strTotalPayAmount']").val(strTotalPayAmountVal);
				}else{
					$("input[name='payTimes']").val(''); //초기화
					$("input[name='strTotalPayAmount']").val(''); //초기화
				}*/
				
				if(fDiscountNumMin != "" && fDiscountNumMax != ""){
					$("#discountTimes").html('').append("<option value=''>선택</option>"); //할인횟수 '선택'으로 초기화
					for(var i= fDiscountNumMin; i<=fDiscountNumMax; i++){
						var optionStr = "<option value=" + i + ">" + 
										 i + 
									"</option>";
					
						$("#discountTimes").append(optionStr);
					}
				}else{
					$("#discountTimes").html('').append("<option value=''>선택</option>"); //할인횟수 '선택'으로 초기화
					$("input[name='strPayTimes']").val(''); //가입납입기간 ''초기화
					$("input[name='payTimes']").val(''); //가입납입기간 초기화
				}
				
			}
		},
		_discountTimesChange: function(f, val){
			var payTypeCd = $("input[name='payTypeCd']:checked").val(); //상품납입기간 선택된 값 , 일시납 혹은 월납
			var discountTimesVal = val; //할인횟수
			var orginPayTimesVal = $("input[name='orginPayTimes']").val(); 		//본래 상품 납입횟수
			var pdtUnitPriceVal = $("input[name='pdtUnitPrice']").val();		//상품금액
			var monthPayAmountVal = $("input[name='monthPayAmount']").val();	//월납입액
			var times = 150; //고정
			var payTimes, strTotalPayAmountVal;
		
			if(typeof payTypeCd != "undefined" && payTypeCd == "2"){ //월납일 경우
				if(discountTimesVal != "" && orginPayTimesVal != ""){
					payTimes = orginPayTimesVal - discountTimesVal; //가입납입기간 = 납입횟수 - 할인횟수
					$("input[name='strPayTimes']").val(payTimes);
					$("input[name='payTimes']").val(payTimes);
				}else{
					$("input[name='strPayTimes']").val(0);
					$("input[name='payTimes']").val(0);
				}
				
				strTotalPayAmountVal = payTimes * monthPayAmountVal; //가입금액 = 가입납입기간 * 월납입액
				
				
			}else if(typeof payTypeCd != "undefined" && payTypeCd == "1"){ //일시납일 경우
				$("input[name='payTimes']").val(0);
				strTotalPayAmountVal = pdtUnitPriceVal - (discountTimesVal * (pdtUnitPriceVal/times));	//가입금액 =  상품금액 - {할인횟수 × (상품금액 ÷ 150)}
			}
			$("input[name='strTotalPayAmount']").val(valComma(strTotalPayAmountVal)); //콤마처리
			$("input[name='totalPayAmount']").val(strTotalPayAmountVal); //콤마값 없는 숫자형 넣기
		},
		_accountNoCert: function(f){
			var custNm = $("input[name='custNm']").val(); //계약자명
			var url ="/ext/contract/accountNoCert-ajax";
			var data =  $(f).serialize();
			$.ajax({
				type : "POST",
				url : url,
				data : data,
				dataType: "json",
				success : function(data){
					var result = data.result;
					var dbPmNo = data.pmNo;
					var popDepositor = $("input[name='popDepositor']").val();
					var popBankCd = $("select[name='popBankCd']").val(); //이체 은행명
					var popAccountNo = $("input[name='popAccountNo']").val(); //계좌번호
					var popDepRelTypeCd; //본인 여부
					$("input[name='pmNo']").val(dbPmNo); //결제수단고유번호 넣기
					if(!$("input[name='popDepRelTypeCd']").is(":checked")) {
						popDepRelTypeCd = 0;
					}else{
						popDepRelTypeCd = 1;
					}
								
					if(result == '1'){
						alert("계좌가 인증되었습니다!\n계속해서 계약 내용을 입력해 주세요.");
						$(".btn-secondary").trigger("click"); //팝업닫기
						
						if(custNm === popDepositor){
							contPayInfo(true, popDepositor, popBankCd, popAccountNo, popDepRelTypeCd); //계약 페이지 예금주 관련 정보 disabled 및 자동 입력(예금주 계약자 동일)
						}else{
							contPayInfo(false, popDepositor, popBankCd, popAccountNo, popDepRelTypeCd); //계약 페이지 예금주 관련 정보 disabled 및 자동 입력(예금주 계약자 동일 X)
						}
					}else if(result == '2'){
						alert("이미 저장되어 있는 계좌정보와 일치합니다.\n계속해서 해당 계좌정보로 계약 등록을 진행해 주세요.");
						$(".btn-secondary").trigger("click"); //팝업닫기
						if(custNm === popDepositor){
							contPayInfo(true, popDepositor, popBankCd, popAccountNo, popDepRelTypeCd); //계약 페이지 예금주 관련 정보 disabled 및 자동 입력(예금주 계약자 동일)
						}else{
							contPayInfo(false, popDepositor, popBankCd, popAccountNo, popDepRelTypeCd); //계약 페이지 예금주 관련 정보 disabled 및 자동 입력(예금주 계약자 동일 X)
						}
						
					}else if(result == '-88'){
						alert("입력하신 예금주명과 실제 예금주명이 불일치\n합니다. 예금주명을 정확히 입력해 주세요.");
					}else{
						alert("계좌 인증에 실패했습니다.\n은행명 및 계좌번호를 정확히 입력해 주세요.");
					}		
					
				},beforeSend:function(){
	            	showLoading();
	            	accountCertBtn(false); //인증버튼 비노출
	            },complete:function(){
	            	hideLoading();
	            	accountCertBtn(true); //인증버튼 노출
	            },error: function(xhr, status, err) {
	            	if (xhr.status == 401) {
	    				alert("접근 권한이 없습니다. 로그인후 다시 시도해 주세요.");
	    			} else if (xhr.status == 403) {
	    				alert("해당 페이지에 대한 권한이 없습니다.");
	    			} else if (xhr.status == 301) {
	    				alert("세션이 끊겼습니다.다시 로그인 해주세요.");
	    				//alert("접근 오류가 발생했습니다. 로그인후 다시 시도해 주세요.");
	    				//location.href = "/";
	    			}else {
	    				alert("처리중 오류가 발생하였습니다. 잠시후 다시 시도해 주세요.");
	    			}
	    			accountCertBtn(true); //인증버튼 노출
	    			hideLoading();
	            }
			});//ajax end		
		},
		_daySelectConfirm: function(y, m, d){
			var url ="/ext/contract/dayConfirm-ajax";
			$.ajax({
				type : "POST",
				url : url,
				data : {"yyyy":y, "mm":m, "day":d},
				dataType: "json",
				success : function(result){	
					if(result < 1){
						alert("선택할 수 없는 일자입니다. 다시 선택해 주세요.\n( 선택가능일자 : 익일 ~ 14일내 )");
					}
				},beforeSend:function(){
	            	showLoading();
	            	
	            },complete:function(){
	            	hideLoading();
	            	
	            },error: function(xhr, status, err) {
	            	if (xhr.status == 401) {
	    				alert("접근 권한이 없습니다. 로그인후 다시 시도해 주세요.");
	    			} else if (xhr.status == 403) {
	    				alert("해당 페이지에 대한 권한이 없습니다.");
	    			} else if (xhr.status == 301) {
	    				alert("세션이 끊겼습니다.다시 로그인 해주세요.");
	    				//alert("접근 오류가 발생했습니다. 로그인후 다시 시도해 주세요.");
	    				//location.href = "/";
	    			}else {
	    				alert("처리중 오류가 발생하였습니다. 잠시후 다시 시도해 주세요.");
	    			}
	    			hideLoading();
	            }
			});//ajax end
		},
		_petSelectTypeJoin: function(obj, val, text){
			if(val=="2"){//가입 불가
				alert("삼성화재보험 “가입불가” 펫("+text+") 종류 입니다.\n다시 선택해 주세요.");
				$(obj).val("").trigger('change');
				//$(obj).selectpicker('refresh');
			}
		},
		_contSave: function(f){
			var url ="/ext/contract/contCreateProc-ajax";
			var data =  $(f).serialize();
			var result;
			$.ajax({
				type : "POST",
				url : url,
				data : data,
				dataType: "json",
				success : function(data){
/*
console.log("data.result : " + data.result);
console.log("data.urlType : " + data.urlType);						
console.log("data.resInfo : " + data.certNos);	
*/					result = data.result;
					if(result == "1"){ //성공
						alert("등록 완료 되었습니다.");
						
						//ARS 출금동의 페이지 이동
						goUrl(data.repCertNo, data.crGrpNo, data.pmNo, data.urlType, "/ext/contract/ars-pop");
					}else{
						if(result == "-11"){
							alert("계좌인증을 진행해주세요.");
						}else if(result == "-12"){
							alert("선택된 초회납 개시일은 선택할 수 없는 일자입니다. 다시 선택해 주세요.\n( 선택가능일자 : 익일 ~ 14일내 )");	
						}else{
							alert("등록중 오류가 발생하였습니다. 관리자에게 문의 하세요. 오류코드"+[result]+"");
						}
					}
		
				},beforeSend:function(){
	            	showLoading();
	            },complete:function(){
	            	hideLoading();
	            },error: function(xhr, status, err) {
		
					//var err = JSON.parse(xhr.responseText);
					//alert(err.message);
		
	            	if (xhr.status == 401) {
	    				alert("접근 권한이 없습니다. 로그인후 다시 시도해 주세요.");
	    			} else if (xhr.status == 403) {
	    				alert("해당 페이지에 대한 권한이 없습니다.");
	    			} else if (xhr.status == 301) {
	    				alert("세션이 끊겼습니다.다시 로그인 해주세요.");
	    				//alert("접근 오류가 발생했습니다. 로그인후 다시 시도해 주세요.");
	    				//location.href = "/";
	    			}else {
	    				alert("처리중 오류가 발생하였습니다. 잠시후 다시 시도해 주세요.");
	    			}
	    			hideLoading();
	            }
			});//ajax end		
		}
	};

	cont.init();
});

//삼품 정보 리셋
function _pdtInfoReset(){
	$(".pdtInfo").find(".pdtName").html('');
	$(".pdtInfo").find(".pdtDescript").html('');
	$("input[name='pdtUnitPrice']").val('');
	$("input[name='strPdtUnitPrice']").val('');
	$(".payTypeCdMonth").html('').append('월납(N회)');
	$("input[name='orginPayTimes']").val('');
	$("input[name='strMonthPayAmount']").val('');
	$("input[name='monthPayAmount']").val('');
	$("#discountTimes").html('').append("<option value=''>선택</option>");
	$("input[name='strPayTimes']").val('');
	$("input[name='strTotalPayAmount']").val('');
	$("input[name='totalPayAmount']").val('');
}

//팝업 계좌인증 버튼 노출여부
function accountCertBtn(flag){
	if(flag){
		$(".popAccCert").show();
	}else{
		$(".popAccCert").hide();
	}
}

//예금주 본인 여부에 따른 동작, 본인 기준 '본인'체크박스가 아닌 예금주명과 계약자명 동일여부가 기준
function contPayInfo(flag, depositor, bankCd, accountNo, epRelTypeCd){
	var bankCdAttr = $("select[name='strBankCd']");
	var accountNoAttr = $("input[name='accountNo']");
	var transferDateAttr = $("select[name='transferDate']");
	var transferStartDateYYYYAttr = $("select[name='transferStartDateYYYY']");
	var transferStartDateMMAttr = $("select[name='transferStartDateMM']");
	var transferStartDateDayAttr = $("select[name='transferStartDateDay']");
	var chkRelTypeCdAttr = $("input:checkbox[name='chkRelTypeCd']");
	var depositorAttr = $("input[name='depositor']"); 
	var relTypeCdAttr = $("select[name='relTypeCd']");
	var birthDateAttr = $("input[name='birthDate']"); //계약자 생년월일
	var depBirthDateAttr = $("input[name='depBirthDate']");
	var depTelNoAttr = $("input[name='depTelNo']");
	var mpNoAttr =  $("input[name='mpNo']"); //계약자 휴대폰 번호
	
	$(bankCdAttr).val(bankCd).prop("selected", true); //자동이체 은행명
	$(accountNoAttr).val(accountNo); //계좌번호
	if(epRelTypeCd == '1'){ //본인여부 체크 박스
		$(chkRelTypeCdAttr).prop("checked", true);
	}else{
		$(chkRelTypeCdAttr).prop("checked", false);
	}
	$(depositorAttr).val(depositor); //예금주
	
	
	/*예금주 관련 정보 disabled, readonly 설정*/
	$("[class$=disableYN]").each (function (index, item) {
		if($(item).attr("disabled") != undefined){
			$(item).attr("disabled", flag);	
		}
		if($(item).attr("readonly") != undefined){
			$(item).attr("readonly", flag);
		}
	});
	
	$("[class$=disableN]").each (function (index, item) {
		$(item).attr("disabled", false);
		//$(item).attr("readonly", false);
	});
	
	//익일 선택하기	
	$("select[name='transferStartDateDay']").find("option").each (function (index, item) {
		var val = $(item).val();
		if(nextDay == val){
			$(item).attr("selected", "selected");
		}
	});
	
	if(flag){ //예금주와 계약자가 동일할 경우
		$(relTypeCdAttr).val(1).prop("selected", true); //관계 선택 본인으로
		$(depBirthDateAttr).val(birthDateAttr.val()); //계약자 생년월일을 예금주 생년월일로 
		$(depTelNoAttr).val(mpNoAttr.val()); //계약자 휴대폰번호를 예금주 연락처로
	}else{//동일하지 않을시
		$(relTypeCdAttr).val("").prop("selected", true);//관계 디폴트 선택
		$(depBirthDateAttr).val(""); 
		$(depTelNoAttr).val("");
	}

}

function petInfoReset(obj){
	$(obj).parents(".petformTable").find("input[name^='petNm_']").val('');
	$(obj).parents(".petformTable").find("select[name^='petTypeCd_']").val('').trigger('change');
	$(obj).parents(".petformTable").find("input[name^='petBirthDate_']").val('');
	$(obj).parents(".petformTable").find("input:radio[name^='petSex_']").prop("checked", false); 
	$(obj).parents(".petformTable").find("input[name^='petRegNo_']").val('');
}


function goUrl(val1, val2, val3, val4, url){
	var f = document.createElement('form');
    var obj;
    obj = document.createElement('input');
    obj.setAttribute('type', 'hidden');
    obj.setAttribute('name', 'certNo');
    obj.setAttribute('value', val1);
	f.appendChild(obj);
	obj = document.createElement('input');
    obj.setAttribute('type', 'hidden');
	obj.setAttribute('name', 'crGrpNo');
    obj.setAttribute('value', val2);
	f.appendChild(obj);
	obj = document.createElement('input');
    obj.setAttribute('type', 'hidden');
    obj.setAttribute('name', 'pmNo');
    obj.setAttribute('value', val3);
    f.appendChild(obj);
	obj = document.createElement('input');
    obj.setAttribute('type', 'hidden');
    obj.setAttribute('name', 'urlType');
    obj.setAttribute('value', val4);
    f.appendChild(obj);
    f.setAttribute('method', 'post');
    f.setAttribute('action', url);
    document.body.appendChild(f);
    f.submit();
}
