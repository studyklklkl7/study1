package com.tenminds.mapper.contract;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.tenminds.domain.contract.model.ContractDto;
import com.tenminds.domain.contract.model.repsonse.ContCurPayInfoDto;
import com.tenminds.domain.contract.model.repsonse.ContCustAgreeDto;
import com.tenminds.domain.contract.model.repsonse.ContPayRoundInfoDto;
import com.tenminds.domain.contract.model.request.ContArsPaContractRequestDto;
import com.tenminds.domain.contract.model.request.ContArsPayAgreeHRequestDto;
import com.tenminds.domain.contract.model.request.ContCertNoMRequestDto;
import com.tenminds.domain.contract.model.request.ContCurPayInfoRequestDto;
import com.tenminds.domain.contract.model.request.ContCustInfoRequestDto;
import com.tenminds.domain.contract.model.request.ContMRequestDto;
import com.tenminds.domain.contract.model.request.ContPayInfoRequestDto;
import com.tenminds.domain.contract.model.request.ContPetInfoRequestDto;
import com.tenminds.domain.contract.model.request.ContRegGrpRequestDto;
import com.tenminds.domain.contract.model.request.SrchContractRequestDto;

/**
 * com.tenminds.mapper.contract
 * ContractMapper.java

 * Description : 계약관리 mapper.<br>
 * Date : 2022. 9. 30.<br>
 * History :<br>
 * - 작성자 : Lee, 날짜 : 2022. 9. 30., 설명 : 최초작성<br>
 *
 * @author Lee
 * @version 1.0
 */
/**
 * com.tenminds.mapper.contract
 * ContractMapper.java

 * Description : 클래스에 대한 설명을 입력해주세요.<br>
 * Date : 2022. 10. 4.<br>
 * History :<br>
 * - 작성자 : Lee, 날짜 : 2022. 10. 4., 설명 : 최초작성<br>
 *
 * @author Lee
 * @version 1.0
 */
@Mapper
public interface ContractMapper {

	List<ContractDto> selectContList(SrchContractRequestDto srchContM) throws Exception;

	int selectContCount(SrchContractRequestDto srchContM)throws Exception;

	List<ContractDto> selectPetListByCont(SrchContractRequestDto srchContract)throws Exception;

	ContractDto selectContractDetail(SrchContractRequestDto srchContract)throws Exception;

	int countContractByPdtCd(String srchPdtCd);

	List<ContCustAgreeDto> selectContCustAgreeList(int custNo);

	List<ContPayRoundInfoDto> selectContPayRoundInfo(SrchContractRequestDto srchContM);

	ContCurPayInfoDto getContCurPayInfo(SrchContractRequestDto srchContM);

	List<ContractDto> selectCertNoListByPayInfo(SrchContractRequestDto srchContM);

	Integer checkAccountState(int payInfoNo);

	int updateContract(ContractDto contractDto);

	int updateContractCust(ContractDto contractDto);

	int updateCustAgree(ContractDto contractDto);

	int insertContStateH(ContractDto contractDto);

	int updateContPayInfo(ContractDto contractDto);

	int updateContractContPmBaInfo(ContractDto contractDto);

	int checkCurPayTimes(String contractNo);

	int getContractStateCd(String contractNo);

	int checkDepRelTypeCd(String pmNo);

	List<ContractDto> selectArsAgreeRequest(String contractNo);

	/**
	 * 계약납입정보고유번호 가져오기
	 * @author : YANG
	 * @date : 2022. 10. 5.
	 * @param String contractNo
	 * @return : int
	 */
	int getPayInfoNoByContractNo(String contractNo);

	/**
	 * 계좌인증 후 계약납입정보 업데이트
	 * @author : YANG
	 * @date : 2022. 10. 5.
	 * @param ContractDto contractDto
	 * @return : int
	 */
	int updateContPayInfoByAccountCert(ContractDto contractDto);

	/**
	 * 계약고유번호로 결제수다-은행계좌정보 가져오기
	 * @author : YANG
	 * @date : 2022. 10. 5.
	 * @param String contractNo
	 * @return : ContractDto
	 */
	ContractDto getContPmBaInfoByContractNo(String contractNo);

	/**
	 * 증서 조회 이력 (계약상세)
	 * @author : YANG
	 * @date : 2022. 10. 6.
	 * @param String certNo
	 * @return : List<SrchContractRequestDto>
	 */
	List<SrchContractRequestDto> selectCertListByCertNo(String certNo);

	/************************************************************************************/

	/**
	 * 계약-결제수단정보 등록
	 * @param  ContractDto contractDto
	 * @return int
	 * @throws SQLException
	*/
	int insertContPayMethodInfo(ContractDto contractDto)throws SQLException;


	/**
	 * 계약-결제수단_은행계좌정보 등록
	 * @param  ContractDto contractDto
	 * @return int
	 * @throws SQLException
	*/
	int insertContPmBaInfo(ContractDto contractDto)throws SQLException;


	/**
	 * 계약-계좌인증히스토리 등록
	 * @param  ContractDto contractDto
	 * @return int
	 * @throws SQLException
	*/
	int insertContBaAuthH(ContractDto contractDto)throws SQLException;


	/**
	 * 계약-계좌인증히스토리 수정
	 * @param  ContractDto contractDto
	 * @return int
	 * @throws SQLException
	*/
	int updateContBaAuthH(ContractDto contractDto)throws SQLException;


	/**
	 * 계약-결제수단_은행계좌정보 수정
	 * @param  ContractDto contractDto
	 * @return int
	 * @throws SQLException
	*/
	int updateContPmBaInfo(ContractDto contractDto)throws SQLException;

	/**
	 * 계약-결제수단정보 시퀀스 조회
	 * @param
	 * @return String
	 * @throws SQLException
	*/
	String selectSeqContPayMethodInfo()throws SQLException;



	/**
	 * 계약-계좌인증히스토리 시퀀스 조회
	 * @author : Lee
	 * @date : 2022. 9. 30.
	 * @return
	 * @throws SQLException
	 * @return : String
	 */
	String selectSeqContBaAuthH()throws SQLException;



	/**
	 * 계약-등록관리 등록
	 * @author : Lee
	 * @date : 2022. 9. 30.
	 * @param contRegGrpRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int insertContractRegGrp(ContRegGrpRequestDto contRegGrpRequestDto)throws SQLException;



	/**
	 * 계약-증서번호 발급관리 등록
	 * @author : Lee
	 * @date : 2022. 9. 30.
	 * @param contCertNoMRequest
	 * @throws SQLException
	 * @return : int
	 */
	int insertContCertNoM(ContCertNoMRequestDto contCertNoMRequestDto)throws SQLException;


	/**
	 * 계약-계약자 정보 등록
	 * @author : Lee
	 * @date : 2022. 9. 30.
	 * @param contCustInfoRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int insertContCustInfo(ContCustInfoRequestDto contCustInfoRequestDto)throws SQLException;


	/**
	 * 계약-고객동의 등록
	 * @author : Lee
	 * @date : 2022. 9. 30.
	 * @param map
	 * @throws SQLException
	 * @return : int
	 */
	int insertCustAgree(Map<String, Object> map)throws SQLException;

	/**
	 * 출금이체증빙 받은 납입정보 카운트 조회
	 * @author : Lee
	 * @date : 2022. 10. 03.
	 * @param contPayInfoRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int selectContPayInfoAaeCert(ContPayInfoRequestDto contPayInfoRequestDto)throws SQLException;

	/**
	 * 계약-납입정보 등록
	 * @author : Lee
	 * @date : 2022. 10. 03.
	 * @param contPayInfoRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int insertContPayInfo(ContPayInfoRequestDto contPayInfoRequestDto)throws SQLException;


	/**
	 * 계약관리 등록
	 * @author : Lee
	 * @date : 2022. 10. 4.
	 * @param contMRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int insertContractM(ContMRequestDto contMRequestDto)throws SQLException;


	/**
	 * 계약-펫정보 등록
	 * @author : Lee
	 * @date : 2022. 10. 4.
	 * @param contPetInfoRequestDto
	 * @return
	 * @throws SQLException
	 * @return : int
	 */
	int insertContpetInfo(ContPetInfoRequestDto contPetInfoRequestDto)throws SQLException;


	/**
	 * 계약-납입현황정보 등록
	 * @author : Lee
	 * @date : 2022. 10. 4.
	 * @param contCurPayInfoRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int insertContCurPayInfo(ContCurPayInfoRequestDto contCurPayInfoRequestDto)throws SQLException;
	
	
	/**
	 * 계약관리 - 납입, 계약 고유번호등 ARS출금동의 정보 등록 위한 정보 리스트 조회 by 계약등록고유번호
	 * @author : Lee
	 * @date : 2022. 10. 8.
	 * @param ContRegGrpRequestDto
	 * @return
	 * @throws SQLException
	 * @return : List<ContractDto>
	 */
	List<ContractDto> selectContMListByCrGrpNo(ContRegGrpRequestDto contRegGrpRequestDto) throws Exception;
	
	
	/**
	 * 계약-ARS출금동의 히스토리 등록
	 * @author : Lee
	 * @date : 2022. 10. 9.
	 * @param ContArsPayAgreeHRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int insertContArsPayAgreeH(ContArsPayAgreeHRequestDto contArsPayAgreeHRequestDto)throws SQLException;
	
	
	/**
	 * 계약-ARS출금동의 대상 _계약목록 등록
	 * @author : Lee
	 * @date : 2022. 10. 9.
	 * @param ContArsPaContractRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int insertContArsPaContract(ContArsPaContractRequestDto contArsPaContractRequestDto)throws SQLException;
	
	
	/**
	 * 계약-납입정보 최종 출금동의고유번호 수정
	 * @author : Lee
	 * @date : 2022. 10. 9.
	 * @param ContPayInfoRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int updateContPayInfoArsPaNo(ContPayInfoRequestDto contPayInfoRequestDto)throws SQLException;

	
	/**
	 * 계약-ARS출금동의 히스토리 동의결과코드 수정
	 * @author : Lee
	 * @date : 2022. 10. 9.
	 * @param ContArsPayAgreeHRequestDto
	 * @throws SQLException
	 * @return : int
	 */
	int updateContArsPayAgreeHResultCd(ContArsPayAgreeHRequestDto contArsPayAgreeHRequestDto)throws SQLException;
}
