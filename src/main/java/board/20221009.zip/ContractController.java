package com.tenminds.controller.contract;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.security.sasl.AuthenticationException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tenminds.common.consts.LogMdc;
import com.tenminds.common.util.DateUtil;
import com.tenminds.common.util.HttpUtil;
import com.tenminds.common.util.JsonUtil;
import com.tenminds.common.util.MoneyUtil;
import com.tenminds.common.util.PagingUtil;
import com.tenminds.common.util.StringUtil;
import com.tenminds.domain.cmn.channel.model.ChannelRecruitDto;
import com.tenminds.domain.cmn.code.model.CodeDto;
import com.tenminds.domain.common.data.model.DateResponseDto;
import com.tenminds.domain.common.data.model.PetIndexResponseDto;
import com.tenminds.domain.common.pet.model.request.PetRequestDto;
import com.tenminds.domain.common.pet.model.response.PetResponseDto;
import com.tenminds.domain.common.pg.model.BankResponseDto;
import com.tenminds.domain.common.resolver.HttpHeader;
import com.tenminds.domain.common.security.LoginInfo;
import com.tenminds.domain.contract.ext.AgentInfoDto;
import com.tenminds.domain.contract.ext.ChannelDto;
import com.tenminds.domain.contract.model.ContractDto;
import com.tenminds.domain.contract.model.repsonse.ContCurPayInfoDto;
import com.tenminds.domain.contract.model.repsonse.ContCustAgreeDto;
import com.tenminds.domain.contract.model.repsonse.ContPayRoundInfoDto;
import com.tenminds.domain.contract.model.repsonse.SiteCertnoSchLogDto;
import com.tenminds.domain.contract.model.request.AccountCertRequestDto;
import com.tenminds.domain.contract.model.request.ContMRequestDto;
import com.tenminds.domain.contract.model.request.ContRegGrpRequestDto;
import com.tenminds.domain.contract.model.request.SrchContractRequestDto;
import com.tenminds.domain.product.entity.PdtBrandC;
import com.tenminds.domain.product.model.ProductDto;
import com.tenminds.service.cmn.channel.ChannelService;
import com.tenminds.service.cmn.code.CodeService;
import com.tenminds.service.cmn.mgr.menu.MenuService;
import com.tenminds.service.cmn.userMgr.UserMgrService;
import com.tenminds.service.common.pet.PetService;
import com.tenminds.service.common.pg.BankService;
import com.tenminds.service.contract.AccountCertService;
import com.tenminds.service.contract.ContService;
import com.tenminds.service.ksnet.KsnetService;
import com.tenminds.service.product.ProductService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j(topic = "DY_LOGGER")
@RequiredArgsConstructor
@Controller
public class ContractController {

	private final ContService contService;

	private final MenuService menuService;

	private final ChannelService channelService;

	private final CodeService codeService;

	private final ProductService productService;

	private final BankService bankService;

	private final AccountCertService accountCertService;

	private final KsnetService ksnetService;

	private final UserMgrService userMgrService;

	private final PetService petService;

	@GetMapping("/view/contract/current")
	public String authList(
			ModelMap model
			,@ModelAttribute SrchContractRequestDto srchContM
			,@AuthenticationPrincipal LoginInfo loginInfo
			,HttpServletRequest request
            ,HttpHeader header
			) throws Exception {
		Map<String, Object> urlMap =  menuService.getUrlInfo(request.getRequestURI());
		model.addAttribute("urlInfo", urlMap);

//		List<CodeC> frontPhoneNumberList = codeService.findAllByCatCd(12);
//		model.addAttribute("frontPhoneNumberList", frontPhoneNumberList);

		model.addAttribute("srchContM", srchContM);
		model.addAttribute("today", StringUtil.dateToString(new Date(), "yyyy-MM-dd"));

		return "view/contract/list";
	}


	@ResponseBody
	@GetMapping("/view/contract/current-paging")
	public Map<String, Object> authListPaging(
			@ModelAttribute SrchContractRequestDto srchContM
			,ModelMap model
			,@AuthenticationPrincipal LoginInfo loginInfo
			,HttpServletRequest request
            ,HttpHeader header
			) throws Exception {
		Map<String, Object> map = new HashedMap<>();

		PagingUtil pagingDto = contService.selectContList(srchContM);

		map.put("pagingDto", pagingDto);
		return map;

	}

	@GetMapping("/view/contract/update")
	public String contractUpdate(
			ModelMap model
			,@ModelAttribute SrchContractRequestDto srchContM
			,@AuthenticationPrincipal LoginInfo loginInfo
			,HttpServletRequest request
            ,HttpHeader header
			) throws Exception {
		String isUse = "1";
		Map<String, Object> urlMap =  menuService.getUrlInfo(request.getRequestURI());
		model.addAttribute("urlInfo", urlMap);

		ContractDto contractDto = contService.selectContractDetail(srchContM);

		List<PdtBrandC> brandList = productService.findAllBrand();

		List<ProductDto> productList = productService.findAllByBrandCd(contractDto.getBrandCd());

		// 27, 예금주관계
		List<CodeDto> depRelTypeList = codeService.codeListBycatCdByuseType(27,1);

		// 26, 이체일자
		List<CodeDto> transferDateList = codeService.codeListBycatCdByuseType(26,1);

		List<ChannelRecruitDto> channelList = channelService.cmnChannelListByIsuse(isUse);

		HashMap<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("isUse", isUse);
		List<ChannelRecruitDto> channelMgrList = channelService.cmnChannelMgrList(paramMap);

		Integer pgCd = 1; //pg사 코드
		Integer pgIsUse = 1; //1:사용, 2:미사용
		List<BankResponseDto> bankList = bankService.bankListByPgCdIsUse(pgCd, pgIsUse);

		model.addAttribute("srchContM", srchContM);
		model.addAttribute("brandList", brandList);
		model.addAttribute("productList", productList);
		model.addAttribute("contractDto", contractDto);
		model.addAttribute("depRelTypeList", depRelTypeList);
		model.addAttribute("channelList", channelList);
		model.addAttribute("channelMgrList", channelMgrList);
		model.addAttribute("bankList", bankList);
		model.addAttribute("transferDateList", transferDateList);
		model.addAttribute("today", StringUtil.dateToString(new Date(), "yyyy-MM-dd"));

		return "view/contract/update";
	}

	@ResponseBody
	@GetMapping("/view/contract/cust-agree-list-ajax")
	public List<ContCustAgreeDto> contractCustAgreeListAjax(
			ModelMap model
			,@ModelAttribute SrchContractRequestDto srchContM
			,@AuthenticationPrincipal LoginInfo loginInfo
			,HttpServletRequest request
            ,HttpHeader header
			) {
		List<ContCustAgreeDto> list = null;
		try {
			list  = contService.selectContCustAgreeList(srchContM.getSrchCustNo());
		} catch (Exception e) {
			log.error("CONTRACT CUST AGREE ERROR [CUST_NO] : " + srchContM.getSrchCustNo() + " / [MESSAGE] " + e.toString());
		}
		return list;
	}

	@ResponseBody
	@GetMapping("/view/contract/check-auth-ajax")
	public int checkAuth(
			@AuthenticationPrincipal LoginInfo loginInfo
            ,HttpHeader header
			) {
		LogMdc.name.accept("contract-controller");
		int result = -1;
		try {
			//우리마인즈 직권자인지 권한 확인
			int woorimindsAuth = 44;
			result = userMgrService.mgrAuthInfoByManagerIdAndAuthCd(loginInfo.getManagerId(),woorimindsAuth);

			if(result == 0) {
				throw new AuthenticationException();
			}
		} catch (Exception e) {
			log.error("CONTRACT CHECK STATE [MESSAGE] " + e.toString());
		}

		return result;
	}

	@ResponseBody
	@GetMapping("/view/contract/pay-round-info-ajax")
	public Map<String, Object> payRoundInfo(
			ModelMap model
			,@ModelAttribute SrchContractRequestDto srchContM
			,@AuthenticationPrincipal LoginInfo loginInfo
			,HttpServletRequest request
            ,HttpHeader header
			) {
		LogMdc.name.accept("contract-controller");
		Map<String, Object> map = new HashMap<String, Object>();

		try {
			List<ContPayRoundInfoDto> payList = new ArrayList<>();
			ContCurPayInfoDto contCurPayInfo = new ContCurPayInfoDto();
			payList = contService.selectContPayRoundInfo(srchContM);
			contCurPayInfo = contService.getContCurPayInfo(srchContM);

			map.put("payList", payList);
			map.put("contCurPayInfo", contCurPayInfo);
		} catch (Exception e) {
			log.error("CONTRACT PAY INFO ERROR [MESSAGE] " + e.toString());
		}
		return map;
	}

	@ResponseBody
	@GetMapping("/view/contract/cert-list-ajax")
	public List<ContractDto> certListAjax(
			ModelMap model
			,@ModelAttribute SrchContractRequestDto srchContM
			,@AuthenticationPrincipal LoginInfo loginInfo
			,HttpServletRequest request
            ,HttpHeader header
			) {
		LogMdc.name.accept("contract-controller");
		List<ContractDto> list = null;
		try {
			list = contService.selectCertNoListByPayInfo(srchContM);
		} catch (Exception e) {
			log.error("CONTRACT CERT NO LIST ERROR [MESSAGE] " + e.toString());
		}
		return list;
	}

	@ResponseBody
	@GetMapping("/view/contract/check-account-state-ajax")
	public int checkAccountStateAjax(
			@RequestParam int payInfoNo
			) {
		LogMdc.name.accept("contract-controller");
		int result = -1;
		try {
			 result = contService.checkAccountState(payInfoNo);
		} catch (Exception e) {
			log.error("CONTRACT PAY INFO ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}

	@ResponseBody
	@PutMapping("/view/contract/update-contract-ajax")
	public int updateContractAjax(
			@ModelAttribute ContractDto contractDto
			,@AuthenticationPrincipal LoginInfo loginInfo
			) {
		LogMdc.name.accept("contract-controller");
		int result = -1;
		try {
			//우리마인즈 직권자인지 권한 확인
			int woorimindsAuth = 44;
			result = userMgrService.mgrAuthInfoByManagerIdAndAuthCd(loginInfo.getManagerId(),woorimindsAuth);

			if(result == 0) {
				log.error("CONTRACT UPDATE ERROR BY AUTH [MANAGER_ID] : " + loginInfo.getManagerId());
				throw new AuthenticationException();
			}else {
				 contractDto.setLUptMgrId(loginInfo.getManagerId());
				 result = contService.updateContract(contractDto);
			}
		} catch (Exception e) {
			log.error("CONTRACT UPDATE ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}

	@ResponseBody
	@GetMapping("/view/contract/check-cur-pay-times-ajax")
	public int checkCurPayTimesAjax(
			@RequestParam String contractNo
			) {
		LogMdc.name.accept("contract-controller");
		int result = -1;
		try {
			 result = contService.checkCurPayTimes(contractNo);
		} catch (Exception e) {
			log.error("CHECK CUR PAY TIMES AJAX ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}

	@ResponseBody
	@GetMapping("/view/contract/contract-code-list-ajax")
	public List<CodeDto> contractCodeListAjax() {
		LogMdc.name.accept("contract-controller");
		List<CodeDto> result = null;
		try {
			// 2, 계약상태
			 result = codeService.codeListBycatCdByuseType(2,1);
		} catch (Exception e) {
			log.error("CONTRACT CODE LIST AJAX ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}

	@ResponseBody
	@GetMapping("/view/contract/ars-agree-request-list-ajax")
	public List<ContractDto> arsAgreeRequestListAjax(@RequestParam String contractNo) {
		LogMdc.name.accept("contract-controller");
		List<ContractDto> result = null;
		try {
			 result = contService.selectArsAgreeRequest(contractNo);
		} catch (Exception e) {
			log.error("ARS AGREE REQUEST LIST [MESSAGE] " + e.toString());
		}
		return result;
	}

	@ResponseBody
	@PutMapping("/view/contract/update-cont-pay-info-ajax")
	public int updateContPayInfoAjax(
			@ModelAttribute ContractDto contractDto
			,@AuthenticationPrincipal LoginInfo loginInfo
			) {
		LogMdc.name.accept("contract-controller");
		int result = -1;
		try {
			//우리마인즈 직권자인지 권한 확인
			int woorimindsAuth = 44;
			result = userMgrService.mgrAuthInfoByManagerIdAndAuthCd(loginInfo.getManagerId(),woorimindsAuth);

			if(result == 0) {
				log.error("CONTRACT UPDATE ERROR BY AUTH [MANAGER_ID] : " + loginInfo.getManagerId());
				throw new AuthenticationException();
			}else {
				 contractDto.setLUptMgrId(loginInfo.getManagerId());
				 result = contService.updateContPayInfoByAccountCert(contractDto);
			}
		} catch (Exception e) {
			log.error("CONTRACT UPDATE ERROR [MESSAGE] " + e.toString());
		}
		return result;
	}

	/**
	 * 증서 조회 이력 (계약상세)
	 * @param String certNo
	 * @return SiteCertnoSchLogDto
	 * @throws Exception
	 */
	@ResponseBody
	@PutMapping("/view/contract/srch-cert-list-ajax")
	public List<SrchContractRequestDto> srchCertListAjax(@RequestParam String certNo) {
		LogMdc.name.accept("contract-controller");
		List<SrchContractRequestDto> list = null;
		try {
			list = contService.selectCertListByCertNo(certNo);
		} catch (Exception e) {
			log.error("CONTRACT UPDATE ERROR [MESSAGE] " + e.toString());
		}
		return list;
	}
	/**********************************************************************************************/


	@GetMapping(value = "/view/test/contM-ajax")
	public String contCreateProcAjax2(@AuthenticationPrincipal LoginInfo loginInfo) throws Exception {
		Integer result = 0; //1:성공, 0:실패
		int accCnt = 2;
		ContRegGrpRequestDto contRegGrpRequest = new ContRegGrpRequestDto();
		String regMgrId = loginInfo.getManagerId(); //등록자 ID
		contRegGrpRequest.setRegMgrId(regMgrId); //set
		contRegGrpRequest.setInsuAccCnt(accCnt);

		ContMRequestDto contMRequest = new ContMRequestDto();
		contMRequest.setAgentOrdNo("222");
		contMRequest.setMonthPayAmount(1000);

		result = contService.contCreateProcAjax2(contRegGrpRequest, contMRequest, loginInfo);

		return "view/cmn/auth/update";
	}
	
	
	//임시임시임시
	@GetMapping(value = "/ext/contract/channel/go")
	public String contchannelGo() throws Exception {

		ChannelDto channelDto = new ChannelDto();
		
		
		
		List<AgentInfoDto> list = new ArrayList<AgentInfoDto>();
		AgentInfoDto agentInfoDto = new AgentInfoDto();
		agentInfoDto.setAgentOrdNo1("20221004");
		agentInfoDto.setAgentOrdNo2("01");
		list.add(agentInfoDto);
		AgentInfoDto agentInfoDto2 = new AgentInfoDto();
		agentInfoDto2.setAgentOrdNo1("20221004");
		agentInfoDto2.setAgentOrdNo2("02");
		list.add(agentInfoDto2);
		
		channelDto.setChannelCd("1");
		channelDto.setChannelKey("18061104");
		channelDto.setAccCnt(2);
		channelDto.setAgentInfoDtos(list);
		
		String url = "http://localhost:8080/ext/contract/channel-pop";
		//HttpUtil 객체 생성
		HttpUtil httpUtil = new HttpUtil();
		//다른 생성자 ( 인코딩 , 타임아웃 )		
		//HttpUtil httpUtil = new HttpUtil("UTF-8" , 7000);
		

		
		
		
		//return "redirect:view/ext/contract/createGo";
			//	return "redirect:/view/ext/contract/create";
		return "view/ext/contract/createGo";
	}



	/**
	 * 등록 페이지
	 * @param channelDto
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping(value = "/{type}/contract/channel-pop", method = {RequestMethod.POST, RequestMethod.GET})
	public String contChannelValidChkCreate(@PathVariable("type") String type, @ModelAttribute("channelDto") ChannelDto channelDto, ModelMap model) throws Exception {
	//public String contChannelValidChkCreate(@RequestParam String channelCd, @RequestParam String channelKey, @RequestParam String agentOrdNo, @RequestParam Integer accCnt, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-contract");
		try {
			Map<String, Object> returnMap = new HashMap<String, Object>();
			int result = 1; //결과값
			String channelCd = "";	//각 채널(대리점)코드
			String channelKey = ""; //각 채널(대리점)들의 key -> 사원번호, 사원ID 등
			String agentOrdNo = "";	//대리점 주문번호
			List<AgentInfoDto> agentInfoDtos = null; //대리점 주문번호 리스트
			List<String> agentOrdNo1 = null; //대리점 주문번호1 리스트
			List<String> agentOrdNo2 = null; //대리점 주문번호2 리스트
			Integer accCnt = 0;			//구좌수
			String isUse = "1"; //1:사용, 2: 미사용
			int catCd = 0;
			int useType = 1;// 1:사용(공통코드)
			String urlType = "2";	////1:보험관리자, 2:팝업 호출
			if(channelDto != null) {
				channelCd = channelDto.getChannelCd();
				channelKey = channelDto.getChannelKey();
				agentOrdNo1 = channelDto.getAgentOrdNo1();
				agentOrdNo2 = channelDto.getAgentOrdNo2();
				accCnt = channelDto.getAccCnt();

			}
			
			
//log.info("channelCd = " + channelCd);
//log.info("channelKey = " + channelKey);
/*	
log.info("channelCd = " + channelCd);
log.info("channelKey = " + channelKey);
log.info("agentOrdNo1 = " + agentOrdNo1);
log.info("agentOrdNo2 = " + agentOrdNo2);
log.info("agentOrdNo1.toString() = " + agentOrdNo1.toString());
log.info("agentOrdNo2.toString() = " + agentOrdNo2.toString());
log.info("accCnt = " + accCnt);
*/
			//1.채널코드 혹은 채널키 혹은 대리점주문번호 혹은 구좌수가 없을 경우
			if(channelCd == null || channelCd.equals("") || channelKey == null || channelKey.equals("") || agentOrdNo1 == null || accCnt == null || accCnt == 0){
				return "redirect:/ext/error?code="+HttpStatus.BAD_REQUEST.value();
			}

			//2.채널(대리점) 리스트
			List<ChannelRecruitDto> channelList = channelService.cmnChannelListByIsuse(isUse);

			//3.채널(대리점) 모집자 리스트
			HashMap<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("channelCd", channelCd);
			paramMap.put("isUse", isUse);
			List<ChannelRecruitDto> channelMgrList = channelService.cmnChannelMgrList(paramMap);

			//4.휴대폰번호 앞자리 리스트
			//catCd = 12; //휴대폰 앞자리
			//List<CodeDto> mpList = codeService.codeListBycatCdByuseType(catCd, useType);

			//5.전화번호앞자리 리스트
			//catCd = 11; //전화번호 앞자리
			//List<CodeDto> telList = codeService.codeListBycatCdByuseType(catCd, useType);

			//6.해당 채널(대리점), 해당 채널키에 대한 해당 보험관리자의 모집자 코드 정보 조회
			HashMap<String, Object> paramMap2 = new HashMap<String, Object>();
			paramMap2.put("channelCd", channelCd);
			paramMap2.put("rmChannelKey", channelKey);
			paramMap2.put("isUse", isUse);
			ChannelRecruitDto crDto = channelService.cmnChannelMgrInfo(paramMap2);
			String recruitMgrCd = "";
			if(crDto != null){
				if(!crDto.getRecruitMgrCd().equals("")) {
					recruitMgrCd = crDto.getRecruitMgrCd();
				}
			}

			//7.브랜드 리스트
			List<PdtBrandC> brandList = productService.findAllBrand();

			//8.구좌수 리스트
			catCd = 19; //구좌수
			List<CodeDto> accCntList = codeService.codeListBycatCdByuseType(catCd, useType);

			//9.납입방법 리스트
			catCd = 20; //구좌수
			List<CodeDto> payTypeList = codeService.codeListBycatCdByuseType(catCd, useType);

			//10.은행사 리스트
			Integer pgCd = 1; //pg사 코드
			Integer pgIsUse = 1; //1:사용, 2:미사용
			List<BankResponseDto> bankList = bankService.bankListByPgCdIsUse(pgCd, pgIsUse);

			//11.이체일자 리스트
			catCd = 26; //이체일자 코드
			List<CodeDto> tranDateList = codeService.codeListBycatCdByuseType(catCd, useType);

			//12.초회납 개시일
			String curYYYY = DateUtil.getYear(); //현재년도
			String nextYYYY = DateUtil.getYear(1); //내년연도
			String curMonth = DateUtil.getMonth(); //현재월
			String nextMonth = DateUtil.getNextMonth(); //다음월
			String[] days = DateUtil.getDDSelect(); //일
			//day 리스트
			ArrayList<DateResponseDto> dayList = new ArrayList<DateResponseDto>();
			DateResponseDto dto = null;
			for(String s: days) {
				dto = new DateResponseDto();
				dto.setDay(s);
				dayList.add(dto);
			}

			//익일
			String nextDayVal = DateUtil.getDay(1);
			String nextDay = "";
			if(nextDayVal.length() == 1){
				nextDay = "0" + nextDayVal;
			}else{
				nextDay = nextDayVal;
			}

			//13.예금주 관계 리스트
			catCd = 27; //구좌수
			List<CodeDto> depRelTypeList = codeService.codeListBycatCdByuseType(catCd, useType);

			//14.구좌수에 따른 펫 리스트
			ArrayList<PetIndexResponseDto> petIndex = new ArrayList<PetIndexResponseDto>();
			PetIndexResponseDto petIndexResponseDto = null;
			int petInfoIndex = 0;
			for(int i=0; i<accCnt; i++){
				petIndexResponseDto = new PetIndexResponseDto();
				petInfoIndex ++;
				petIndexResponseDto.setIndex(petInfoIndex);
				petIndex.add(petIndexResponseDto);
			}

			//15.펫 리스트
			PetRequestDto petRequestDto = new PetRequestDto();
			catCd = 10;
			petRequestDto.setPicCd(1); //1:삼성화재
			petRequestDto.setCatCd(catCd); //펫코드
			petRequestDto.setUseType(1); //1:사용, 2:미사용
			List<PetResponseDto> petList = petService.petListByPicCdByUseType(petRequestDto);
			
			//16.대리점 주문번호's
			for(String s: days) {
				dto = new DateResponseDto();
				dto.setDay(s);
				dayList.add(dto);
			}
			
			/*
			String agentOrdNo1 = "";
			String agentOrdNo2 = "";
			String agentOrdNos = "";
			int forIdx = 0;
			for(AgentInfoDto agentInfoDto: agentInfoDtos) {
				
				agentOrdNo1 = agentInfoDto.getAgentOrdNo1(); //대리점주문번호1
				agentOrdNo2 = agentInfoDto.getAgentOrdNo2(); //대리점주문번호2
				agentOrdNo = agentOrdNo1+agentOrdNo2; //대리점주문번호
				
				if(forIdx > 0){
					agentOrdNos = agentOrdNos + "/" + agentOrdNo;
				}else {
					agentOrdNos = agentOrdNo;
				}
	
				forIdx++;		
			}
			*/
			String agentOrdNos = "";
			int forIdx = 0;
			for(String s: agentOrdNo1) {
				agentOrdNo = agentOrdNo1.get(forIdx)+agentOrdNo2.get(forIdx);
				if(forIdx > 0){
					agentOrdNos = agentOrdNos + "/" + agentOrdNo;
				}else {
					agentOrdNos = agentOrdNo;
				}
				
				forIdx++;
			}
		
			//add
			//orgin model.addAttribute("channelDto", channelDto);
			model.addAttribute("channelCd", channelCd);
			model.addAttribute("channelKey", channelKey);
			model.addAttribute("agentOrdNo", agentOrdNo);
			model.addAttribute("channelList", channelList);
			model.addAttribute("channelMgrList", channelMgrList);
			model.addAttribute("recruitMgrCd", recruitMgrCd);
			//model.addAttribute("mpList", mpList);
			//model.addAttribute("telList", telList);
			model.addAttribute("brandList", brandList);
			model.addAttribute("accCntList", accCntList);
			model.addAttribute("payTypeList", payTypeList);
			model.addAttribute("bankList", bankList);
			model.addAttribute("tranDateList", tranDateList);
			model.addAttribute("curYYYY", curYYYY);
			model.addAttribute("nextYYYY", nextYYYY);
			model.addAttribute("curMonth", curMonth);
			model.addAttribute("nextMonth", nextMonth);
			model.addAttribute("dayList", dayList);
			model.addAttribute("nextDay", nextDay);
			model.addAttribute("depRelTypeList", depRelTypeList);
			model.addAttribute("petIndex", petIndex);
			model.addAttribute("accCnt", accCnt);
			model.addAttribute("petList", petList);
			model.addAttribute("agentOrdNo1", agentOrdNo1);
			model.addAttribute("agentOrdNo2", agentOrdNo2);
			model.addAttribute("agentOrdNos", agentOrdNos);
			model.addAttribute("urlType", urlType);
			 

		}catch (Exception e) {
			log.error("ContractController > contChannelValidChkCreate : " + e.toString());
		}

		return "view/ext/contract/create";
	}//contChannelValidChkCreate end



	/**
	 * 브랜드 코드별 상품리스트
	 * @param brandCd
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping(value = "/{type}/contract/productList-ajax", method = {RequestMethod.POST})
	@ResponseBody
	public String contProductListAjax(@PathVariable("type") String type, @RequestParam("brandCd") String brandCd, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-contract");
		String result = "";
		try {

			//브랜드 코드별 상품 리스트
			List<ProductDto> list = productService.findAllByBrandCd(brandCd);

			//to json
			result = JsonUtil.objectToJson(list);

		} catch (Exception e) {
			// TODO: handle exception
			log.error("ContractController > contProductListAjax : " + e.toString());
		}
		return result;
	}


	/**
	 * 상품정보 조회
	 * @param pdtCd
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping(value = "/{type}/contract/productInfo-ajax", method = {RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> contProductInfoAjax(@PathVariable("type") String type, @RequestParam("pdtCd") String pdtCd, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-contract");
		Map<String, Object> returnMap = null;
		String pdtName = "";
		String pdtDescript = "";
		int pdtUnitPrice = 0; //상품금액
		String strPdtUnitPrice = "";
		int payTimes = 0;//납입횟수
		int monthPayAmount = 0;
		String strMonthPayAmount = "";
		int fDiscountNumMin = 0;
		int fDiscountNumMax = 0;
		int mDiscountNumMin = 0;
		int mDiscountNumMax = 0;
		try {
			returnMap = new HashMap<String, Object>();


			//브랜드 코드별 상품 리스트
			ProductDto productDto = productService.findById(pdtCd);

			pdtName = productDto.getPdtName(); //상품명
			pdtDescript = productDto.getPdtDescript(); //상품설명
			pdtUnitPrice = productDto.getPdtUnitPrice(); //상품금액
			strPdtUnitPrice = MoneyUtil.getMoneyFmt(pdtUnitPrice); //금액 , 처리
			payTimes = productDto.getPayTimes();	//납입횟수
			monthPayAmount = productDto.getMonthPayAmount(); 	//월납입액
			strMonthPayAmount = MoneyUtil.getMoneyFmt(monthPayAmount); //금액 , 처리
			fDiscountNumMin = productDto.getFDiscountNumMin(); 	//일시납 할인횟수-최소
			fDiscountNumMax = productDto.getFDiscountNumMax();	//일시납 할인횟수-최대
			mDiscountNumMin = productDto.getMDiscountNumMin();	//월납 할인횟수-최소
			mDiscountNumMax = productDto.getMDiscountNumMax();	//월납 할인횟수-최대

			returnMap.put("pdtName", pdtName);
			returnMap.put("pdtDescript", pdtDescript);
			returnMap.put("pdtUnitPrice", pdtUnitPrice);
			returnMap.put("strPdtUnitPrice", strPdtUnitPrice);
			returnMap.put("payTimes", payTimes);
			returnMap.put("monthPayAmount", monthPayAmount);
			returnMap.put("strMonthPayAmount", strMonthPayAmount);
			returnMap.put("fDiscountNumMin", fDiscountNumMin);
			returnMap.put("fDiscountNumMax", fDiscountNumMax);
			returnMap.put("mDiscountNumMin", mDiscountNumMin);
			returnMap.put("mDiscountNumMax", mDiscountNumMax);

		} catch (Exception e) {
			// TODO: handle exception
			log.error("ContractController > contProductInfoAjax : " + e.toString());
		}
		return returnMap;
	}




	/**
	 * 계좌인증 처리
	 * @author : Lee
	 * @date : 2022. 10. 6.
	 * @param type
	 * @param accountCertRequestDto
	 * @param model
	 * @throws Exception
	 * @return : Map<String,Object>
	 */
	@RequestMapping(value = "/{type}/contract/accountNoCert-ajax", method = {RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> accountNoCertProcAjax(@PathVariable("type") String type, @ModelAttribute("accountCertRequestDto") AccountCertRequestDto accountCertRequestDto, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-contract-accountCert");		
		
		Map<String, Object> returnMap = null;

		try {
			//System.out.print("111 == " + AES256Util.strEncode("25812227112001", Security.AES_SECRET_KEY));
			/*
			 * returnMap key result
			 * 2:이미 인증 받은 내역이 있음, -88: 인증 조회 받은 예금주명과 입력한 에금주명이 다름
			 * 1:성공,  -99: 인증 요청 등록 실패,인증 수신 결과 실패
			 * */
			returnMap = contService.contMethodPmBaAuthInsertProc(accountCertRequestDto);


		} catch (Exception e) {
			// TODO: handle exception
			log.error("ContractController > accountNoCertProcAjax : " + e.toString());
		}
		return returnMap;
	}


	/**
	 * 초회납 개시일 유효성 체크
	 * @param AccountCertRequestDto accountCertRequestDto
	 * @param ModelMap model
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	@RequestMapping(value = "/{type}/contract/dayConfirm-ajax", method = {RequestMethod.POST})
	@ResponseBody
	public String dayConfirmAjax(@PathVariable("type") String type, @RequestParam HashMap<String, String> paramMap, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-contract");
		String result = "1";
		int limitDate = 14;
		try {
			String yyyy = paramMap.get("yyyy").toString();
			String mm = paramMap.get("mm").toString();
			String day = paramMap.get("day").toString();
			long dateDiff = 0L;

			//현재일
			String curYYYMMDay = DateUtil.getDateFmt("yyyyMMdd");

			//선택한 초회납 개시일
			String tranStartDate = yyyy+mm+day;

			dateDiff = DateUtil.diffOfDate(curYYYMMDay, tranStartDate);

			if(dateDiff < 0 || dateDiff > limitDate){ //선택한 초회납 게시일이 0보다 작거나 15일 이상이면
				result = "0";
			}

		} catch (Exception e) {
			// TODO: handle exception
			log.error("ContractController > dayConfirmAjax : " + e.toString());
		}
		return result;
	}


	/**
	 * 모집자 정보조회
	 * @param recruitMgrId
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping(value = "/{type}/contract/recruitMgrInfo-ajax", method = {RequestMethod.POST})
	@ResponseBody
	public String contRecruitMgrInfoAjax(@PathVariable("type") String type, @RequestParam("recruitMgrCd") String recruitMgrCd, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-contract");
		String result = "";
		try {

			HashMap<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("recruitMgrCd", recruitMgrCd);
			ChannelRecruitDto crDto = channelService.cmnChannelMgrInfo(paramMap);
			String rmChannelKey = ""; //모집자 채널키
			if(crDto != null){
				if(!crDto.getRmChannelKey().equals("")) {
					rmChannelKey = crDto.getRmChannelKey();
					result = rmChannelKey;
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
			log.error("ContractController > contRecruitMgrInfoAjax : " + e.toString());
		}
		return result;
	}


	/**
	 * 계약 등록 처리
	 * @param ContractDto contractDto
	 * @param ModelMap model
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	@RequestMapping(value = "/{type}/contract/contCreateProc-ajax", method = {RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> contCreateProcAjax(@PathVariable("type") String type, @ModelAttribute("ContractDto") ContractDto contractDto, @AuthenticationPrincipal LoginInfo loginInfo, @Value("${spring.agent.tm-ob.cert-response-url}") String url, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-contract-createProc");
		Map<String, Object> returnMap = null;
		try {
			/*
			 * returnMap key result
			 * -1: 계약자 생년월이 8자리 error, -2: 필수적 수집, 이용 값이 미동의 값으로 넘어왔을때, -3: 필수적 제공 값이 미동의 값으로 넘어 왔을때
			 * -4: 파라메터 넘어온 상품 금액과 DB조회 상품 금액이 다르면, -5: //파라메터 넘어온 월납입액과 DB조회 월납입액이 다르면
			 * -6: 파라메터 넘어온 할인횟수가 일시납 할인횟수-최대보다 크면, -7: 파라메터 넘어온 할인횟수가 월납 할인횟수-최대보다 크면
			 * -8: 파라메터 가입금액과 검증 가입금액이 다르면(일시납), -9:파라메터 가입금액과 검증 가입금액이 다르면(월납)
			 * -10: 파라메터 넘어온 가입납입기간과 검증 (가입납입기간-할인횟수) 값이 다르면
			 * -11: 계좌인증 완료를 안했을 경우, -12: 선택한 초회납 게시일이 0보다 작거나 15일 이상이면
			 * -13: 예금주 생년월일 8자 error, -14: 선택적 수집, 이용 매체 값들 error
			 * -99: 등록처리 오류
			 * 1:성공
			 * */
			//로그인 정보
			Optional<LoginInfo> optLoginInfo = Optional.<LoginInfo>empty();

			returnMap = contService.contCreateProc(contractDto, optLoginInfo, url);
		} catch (Exception e) {
			// TODO: handle exception
			log.error("ContractController > contCreateProcAjax : " + e.toString());
			returnMap.put("result", "-100");
			return returnMap;
		}
		return returnMap;
	}
	
	
	
	/**
	 * ARS 출금동의 페이지 
	 * @author : Lee
	 * @date : 2022. 10. 6.
	 * @param type
	 * @param channelDto
	 * @param model
	 * @throws Exception
	 * @return : String
	 */
	@RequestMapping(value = "/{type}/contract/ars-pop", method = {RequestMethod.POST, RequestMethod.GET})
	public String contArsCreate(@PathVariable("type") String type, @ModelAttribute("ontractDto") ContractDto contractDto, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-channel-contract");
		try {
			Map<String, Object> returnMap = new HashMap<String, Object>();
			int result = 1; //결과값
			
			String repCertNo = contractDto.getCertNo();
			int crGrpNo =  contractDto.getCrGrpNo();
			String repPmNo = contractDto.getPmNo();
			String urlType = contractDto.getUrlType();  //1:보험관리자, 2:팝업 호출
			
			//생성 및 증서번호 set
			SrchContractRequestDto srchContM = new SrchContractRequestDto();
			srchContM.setSrchCertNo(repCertNo);
			
			//계약 상세 조회
			contractDto = contService.selectContractDetail(srchContM);
	
			model.addAttribute("contractDto", contractDto);
			model.addAttribute("crGrpNo", crGrpNo);
			model.addAttribute("repPmNo", repPmNo);
			model.addAttribute("urlType", urlType);

		}catch (Exception e) {
			log.error("ContractController > contArsCreate : " + e.toString());
		}

		return "view/ext/contract/ars-create";
	}
	
	
	
	/**
	 * ARS출금 동의 처리
	 * @param ContractDto contractDto
	 * @param ModelMap model
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	@RequestMapping(value = "/{type}/contract/contArsProc-ajax", method = {RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> contArsProcAjax(@PathVariable("type") String type, @ModelAttribute("ContractDto") ContractDto contractDto, @AuthenticationPrincipal LoginInfo loginInfo, @Value("${spring.ars.request-url}") String url, @Value("${spring.ars-const.req-ing}") int arsReqIng, ModelMap model) throws Exception {
		LogMdc.name.accept(type+"-contract-arsProc");
		Map<String, Object> returnMap = null;
		try {
			/*
			 * returnMap key result
			 * -1: 계약자 생년월이 8자리 error, -2: 필수적 수집, 이용 값이 미동의 값으로 넘어왔을때

			 * -99: 등록처리 오류
			 * 1:성공
			 * */
			//로그인 정보
			Optional<LoginInfo> optLoginInfo = Optional.<LoginInfo>empty();

			returnMap = contService.contArsProc(contractDto, optLoginInfo, url, arsReqIng);

			
		} catch (Exception e) {
			// TODO: handle exception
			log.error("ContractController > contArsProcAjax : " + e.toString());
			returnMap.put("result", "-100");
			return returnMap;
		}
		return returnMap;
	}
	
	
}